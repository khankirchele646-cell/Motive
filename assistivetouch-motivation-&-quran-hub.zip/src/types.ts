export interface MotivationVideo {
  id: string;
  title: string;
  category: 'despair' | 'hardship' | 'peace' | 'strength' | 'general';
  customNote?: string;
  blob?: Blob;
  blobUrl?: string;
  videoUrl?: string; // For built-in preloaded videos
  thumbnail?: string;
  duration?: number;
  fileSize?: number;
  dateAdded: number;
  isPrimary: boolean;
}

export interface QuranAyah {
  id: string;
  surah: string;
  surahNumber: number;
  verseNumber: number;
  arabic: string;
  bangla: string;
  english: string;
  category: 'despair' | 'hardship' | 'peace' | 'strength' | 'provision';
  categoryLabelBn: string;
  reflectionBn: string;
  reflectionEn: string;
  isFavorite?: boolean;
}

export type OrbTheme = 'emerald' | 'apple-dark' | 'gold' | 'sky' | 'rose' | 'amethyst';
export type OrbIcon = 'classic-touch' | 'crescent' | 'heart' | 'sparkles' | 'flame' | 'play';
export type OrbClickBehavior = 'open_menu' | 'play_primary_video' | 'show_quran_verse';

export interface AssistiveTouchSettings {
  enabled: boolean;
  size: number; // in pixels (e.g., 56)
  idleOpacity: number; // 0.2 to 1.0
  activeOpacity: number; // 0.8 to 1.0
  theme: OrbTheme;
  iconStyle: OrbIcon;
  clickBehavior: OrbClickBehavior;
  snapToEdge: boolean;
  hapticFeedback: boolean;
  position: { x: number; y: number }; // normalized percent 0-100
}

export type TabType = 'home' | 'videos' | 'quran' | 'touch_settings' | 'settings';
