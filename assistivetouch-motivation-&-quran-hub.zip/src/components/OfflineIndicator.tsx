import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff, Database } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 rounded-full bg-emerald-950/90 border border-emerald-500/40 px-3.5 py-1.5 text-xs font-medium text-emerald-200 shadow-xl backdrop-blur-md animate-fade-in">
      <WifiOff className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
      <span>অফলাইন মোড সক্রিয় — ভিডিও ও আয়াত ডিভাইসেই সংরক্ষিত</span>
      <Database className="w-3 h-3 text-emerald-300 ml-1" />
    </div>
  );
};
