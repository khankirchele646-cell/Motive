import React, { useState, useEffect } from 'react';
import { X, Wind, Heart, Sparkles, RefreshCw } from 'lucide-react';
import { playGroundingBowl, playHapticTick } from '../lib/soundEffects';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

type Phase = 'inhale' | 'hold' | 'exhale' | 'rest';

export const BreathingExerciseModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [phase, setPhase] = useState<Phase>('inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);
  const [cycleCount, setCycleCount] = useState(1);

  useEffect(() => {
    if (!isOpen) {
      setPhase('inhale');
      setSecondsLeft(4);
      setCycleCount(1);
      return;
    }

    playGroundingBowl();

    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          // Switch phase
          if (phase === 'inhale') {
            setPhase('hold');
            return 7;
          } else if (phase === 'hold') {
            setPhase('exhale');
            return 8;
          } else if (phase === 'exhale') {
            setPhase('inhale');
            setCycleCount((c) => c + 1);
            playGroundingBowl();
            return 4;
          }
          return 4;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, phase]);

  if (!isOpen) return null;

  const getPhaseText = () => {
    switch (phase) {
      case 'inhale':
        return {
          title: 'নাক দিয়ে গভীর শ্বাস নিন...',
          sub: 'বুক ভরে বাতাস নিন এবং মন শান্ত রাখুন',
          color: 'text-teal-300',
          ringColor: 'border-teal-400',
          scale: 'scale-125',
          bgGlow: 'bg-teal-500/20',
        };
      case 'hold':
        return {
          title: 'শ্বাস ধরে রাখুন...',
          sub: 'শান্ত ও স্থির থাকুন, আল্লাহ আপনার সাথে আছেন',
          color: 'text-amber-300',
          ringColor: 'border-amber-400',
          scale: 'scale-125',
          bgGlow: 'bg-amber-500/20',
        };
      case 'exhale':
        return {
          title: 'মুখ দিয়ে ধীরে ধীরে শ্বাস ছাড়ুন...',
          sub: 'সকল চিন্তা, ভয় এবং মানসিক চাপ বের করে দিন',
          color: 'text-emerald-300',
          ringColor: 'border-emerald-400',
          scale: 'scale-90',
          bgGlow: 'bg-emerald-500/20',
        };
      default:
        return {
          title: 'প্রস্তুত হোন...',
          sub: 'সহজভাবে বসুন',
          color: 'text-slate-200',
          ringColor: 'border-slate-400',
          scale: 'scale-100',
          bgGlow: 'bg-slate-500/10',
        };
    }
  };

  const current = getPhaseText();

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-sm rounded-3xl bg-slate-900 border border-teal-500/30 p-6 shadow-2xl text-center text-white relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => {
            playHapticTick();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center justify-center gap-2 text-teal-400 mb-2">
          <Wind className="w-5 h-5 animate-pulse" />
          <h3 className="text-sm font-bold">মন শান্ত করার শ্বাস-প্রশ্বাস (Box Breathing)</h3>
        </div>
        <p className="text-xs text-slate-400 font-bangla mb-6">
          চরম মানসিক চাপ, অস্থিরতা ও হতাশার মুহূর্ত থেকে মনকে স্থির করুন
        </p>

        {/* Animated Breathing Circle */}
        <div className="relative w-48 h-48 mx-auto flex items-center justify-center my-4">
          {/* Ambient Glow */}
          <div
            className={`absolute inset-0 rounded-full blur-2xl transition-all duration-1000 ${current.bgGlow}`}
          />

          {/* Outer Breathing Expanding Ring */}
          <div
            className={`w-44 h-44 rounded-full border-2 ${current.ringColor} border-dashed flex items-center justify-center transition-transform duration-[3000ms] ease-in-out ${current.scale}`}
          >
            {/* Inner Pulsing Core */}
            <div className="w-32 h-32 rounded-full bg-gradient-to-tr from-slate-950 to-slate-800 border border-white/20 flex flex-col items-center justify-center shadow-inner">
              <span className="text-4xl font-extrabold text-white font-mono">
                {secondsLeft}
              </span>
              <span className="text-[11px] text-slate-400 font-bangla mt-1">সেকেন্ড</span>
            </div>
          </div>
        </div>

        {/* Phase Text */}
        <div className="mt-4 font-bangla">
          <h4 className={`text-lg font-bold ${current.color} transition-colors duration-500`}>
            {current.title}
          </h4>
          <p className="text-xs text-slate-300 mt-1 max-w-xs mx-auto">
            {current.sub}
          </p>
        </div>

        {/* Cycle Counter */}
        <div className="mt-6 pt-3 border-t border-white/10 flex items-center justify-between text-xs text-slate-400 font-bangla">
          <span>চক্র: {cycleCount} বার সম্পন্ন</span>
          <span className="text-teal-400">প্রতিদিন ১-২ মিনিট করুন</span>
        </div>
      </div>
    </div>
  );
};
