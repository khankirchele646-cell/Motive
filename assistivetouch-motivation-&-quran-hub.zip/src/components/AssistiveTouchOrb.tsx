import React, { useState, useEffect, useRef } from 'react';
import { AssistiveTouchSettings, MotivationVideo, QuranAyah } from '../types';
import { playHapticTick, playChimePeace } from '../lib/soundEffects';
import { 
  Play, 
  BookOpen, 
  Sparkles, 
  Heart, 
  Flame, 
  Moon, 
  Upload, 
  Sliders, 
  Maximize2, 
  Wind,
  X,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

interface Props {
  settings: AssistiveTouchSettings;
  primaryVideo: MotivationVideo | null;
  onOpenVideoPlayer: (video?: MotivationVideo) => void;
  onOpenQuranModal: (ayah?: QuranAyah) => void;
  onOpenUpload: () => void;
  onOpenBreathingModal: () => void;
  onOpenSettingsTab: () => void;
  onRequestPiP: () => void;
}

export const AssistiveTouchOrb: React.FC<Props> = ({
  settings,
  primaryVideo,
  onOpenVideoPlayer,
  onOpenQuranModal,
  onOpenUpload,
  onOpenBreathingModal,
  onOpenSettingsTab,
  onRequestPiP,
}) => {
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 20, y: 300 });
  const [isDragging, setIsDragging] = useState(false);
  const [isIdle, setIsIdle] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const dragStartRef = useRef<{ startX: number; startY: number; orbX: number; orbY: number; moved: boolean }>({
    startX: 0,
    startY: 0,
    orbX: 0,
    orbY: 0,
    moved: false,
  });
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize position from settings or default right margin
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const initX = (window.innerWidth * (settings.position?.x ?? 88)) / 100 - settings.size / 2;
      const initY = (window.innerHeight * (settings.position?.y ?? 65)) / 100 - settings.size / 2;
      setPosition({
        x: Math.max(12, Math.min(window.innerWidth - settings.size - 12, initX)),
        y: Math.max(20, Math.min(window.innerHeight - settings.size - 80, initY)),
      });
    }
  }, [settings.size]);

  // Handle idle dimming (like iOS AssistiveTouch)
  const resetIdleTimer = () => {
    setIsIdle(false);
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => {
      if (!isMenuOpen) {
        setIsIdle(true);
      }
    }, 3200);
  };

  useEffect(() => {
    resetIdleTimer();
    return () => {
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, [isMenuOpen]);

  // Pointer Drag Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(true);
    setIsIdle(false);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      orbX: position.x,
      orbY: position.y,
      moved: false,
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragStartRef.current.startX;
    const dy = e.clientY - dragStartRef.current.startY;
    if (Math.hypot(dx, dy) > 5) {
      dragStartRef.current.moved = true;
    }

    const newX = dragStartRef.current.orbX + dx;
    const newY = dragStartRef.current.orbY + dy;

    // Boundaries
    const maxX = window.innerWidth - settings.size - 10;
    const maxY = window.innerHeight - settings.size - 70;

    setPosition({
      x: Math.max(10, Math.min(maxX, newX)),
      y: Math.max(16, Math.min(maxY, newY)),
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);

    // If snap to edge is enabled, magnetize to nearest left or right margin
    if (settings.snapToEdge) {
      const screenMid = window.innerWidth / 2;
      const targetX = position.x < screenMid ? 12 : window.innerWidth - settings.size - 12;
      setPosition((prev) => ({ ...prev, x: targetX }));
    }

    // Check if it was a tap/click
    if (!dragStartRef.current.moved) {
      handleOrbClick();
    } else {
      resetIdleTimer();
    }
  };

  const handleOrbClick = () => {
    if (settings.hapticFeedback) playHapticTick();

    if (settings.clickBehavior === 'play_primary_video') {
      playChimePeace();
      onOpenVideoPlayer(primaryVideo || undefined);
    } else if (settings.clickBehavior === 'show_quran_verse') {
      playChimePeace();
      onOpenQuranModal();
    } else {
      // Default: open Apple AssistiveTouch style radial control menu
      setIsMenuOpen((prev) => !prev);
    }
  };

  if (!settings.enabled) return null;

  // Theme color styles
  const getThemeClasses = () => {
    switch (settings.theme) {
      case 'emerald':
        return {
          glow: 'shadow-[0_0_24px_rgba(16,185,129,0.45)]',
          border: 'border-emerald-500/40',
          innerGlow: 'from-emerald-400 to-teal-600',
          accent: 'text-emerald-400',
          menuBg: 'bg-slate-900/90 border-emerald-500/30',
        };
      case 'gold':
        return {
          glow: 'shadow-[0_0_24px_rgba(245,158,11,0.45)]',
          border: 'border-amber-400/40',
          innerGlow: 'from-amber-300 to-yellow-600',
          accent: 'text-amber-400',
          menuBg: 'bg-slate-900/90 border-amber-500/30',
        };
      case 'sky':
        return {
          glow: 'shadow-[0_0_24px_rgba(56,189,248,0.45)]',
          border: 'border-sky-400/40',
          innerGlow: 'from-sky-300 to-blue-600',
          accent: 'text-sky-400',
          menuBg: 'bg-slate-900/90 border-sky-500/30',
        };
      case 'rose':
        return {
          glow: 'shadow-[0_0_24px_rgba(244,63,94,0.45)]',
          border: 'border-rose-400/40',
          innerGlow: 'from-rose-300 to-pink-600',
          accent: 'text-rose-400',
          menuBg: 'bg-slate-900/90 border-rose-500/30',
        };
      case 'amethyst':
        return {
          glow: 'shadow-[0_0_24px_rgba(168,85,247,0.45)]',
          border: 'border-purple-400/40',
          innerGlow: 'from-purple-300 to-indigo-600',
          accent: 'text-purple-400',
          menuBg: 'bg-slate-900/90 border-purple-500/30',
        };
      case 'apple-dark':
      default:
        return {
          glow: 'shadow-[0_0_20px_rgba(255,255,255,0.2)]',
          border: 'border-white/30',
          innerGlow: 'from-slate-100 to-slate-400',
          accent: 'text-slate-200',
          menuBg: 'bg-neutral-900/92 border-neutral-700/60',
        };
    }
  };

  const theme = getThemeClasses();
  const currentOpacity = isDragging
    ? 1
    : isIdle
    ? settings.idleOpacity
    : settings.activeOpacity;

  return (
    <>
      {/* FLOATING DRAGGABLE ASSISTIVETOUCH ORB */}
      <div
        id="assistive-touch-orb"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onMouseEnter={() => {
          setIsIdle(false);
          if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
        }}
        onMouseLeave={resetIdleTimer}
        style={{
          transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
          width: `${settings.size}px`,
          height: `${settings.size}px`,
          opacity: currentOpacity,
          transition: isDragging ? 'none' : 'transform 0.22s cubic-bezier(0.2, 0.9, 0.3, 1), opacity 0.3s ease',
        }}
        className={`fixed top-0 left-0 z-[90] cursor-grab active:cursor-grabbing select-none touch-none rounded-[28%] p-1.5 flex items-center justify-center backdrop-blur-xl ${theme.glow} transition-shadow duration-300`}
      >
        {/* Outer Frosted Shell */}
        <div
          className={`w-full h-full rounded-[26%] bg-slate-950/75 border ${theme.border} flex items-center justify-center relative overflow-hidden shadow-inner`}
        >
          {/* Subtle Rotating Light Sweep */}
          <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-transparent to-transparent opacity-60" />

          {/* Middle Translucent Layer */}
          <div className="w-[74%] h-[74%] rounded-[24%] bg-slate-800/80 border border-white/15 flex items-center justify-center shadow-sm">
            {/* Inner Core Symbol */}
            {settings.iconStyle === 'classic-touch' ? (
              <div className="w-[58%] h-[58%] rounded-full bg-white/95 shadow-md flex items-center justify-center ring-2 ring-white/30">
                <div className="w-[45%] h-[45%] rounded-full bg-slate-900/90" />
              </div>
            ) : settings.iconStyle === 'crescent' ? (
              <Moon className="w-[60%] h-[60%] text-emerald-300 fill-emerald-300/40" />
            ) : settings.iconStyle === 'heart' ? (
              <Heart className="w-[60%] h-[60%] text-rose-400 fill-rose-400/40" />
            ) : settings.iconStyle === 'sparkles' ? (
              <Sparkles className="w-[60%] h-[60%] text-amber-300" />
            ) : settings.iconStyle === 'flame' ? (
              <Flame className="w-[60%] h-[60%] text-orange-400 fill-orange-400/40" />
            ) : (
              <Play className="w-[55%] h-[55%] text-emerald-400 fill-emerald-400 ml-0.5" />
            )}
          </div>
        </div>

        {/* Pulse Indicator when primary video is ready */}
        {primaryVideo && (
          <span className="absolute -top-1 -right-1 flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border border-slate-950"></span>
          </span>
        )}
      </div>

      {/* RADIAL ASSISTIVETOUCH EXPANDED MENU */}
      {isMenuOpen && (
        <div
          className="fixed inset-0 z-[95] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-fade-in"
          onClick={() => setIsMenuOpen(false)}
        >
          <div
            className={`w-full max-w-[340px] rounded-3xl ${theme.menuBg} border p-5 shadow-2xl backdrop-blur-2xl text-white relative`}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm font-bold tracking-tight">মোটিভেশন মেনু (AssistiveTouch)</h3>
                  <p className="text-[11px] text-slate-400 font-bangla">হতাশা দূর করতে যে কোনোটি বেছে নিন</p>
                </div>
              </div>
              <button
                onClick={() => setIsMenuOpen(false)}
                className="p-1.5 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Actions Grid */}
            <div className="grid grid-cols-3 gap-3 my-4">
              {/* 1. Play Motivation Video */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  playChimePeace();
                  onOpenVideoPlayer(primaryVideo || undefined);
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-gradient-to-b from-emerald-500/20 to-teal-900/30 hover:from-emerald-500/30 hover:to-teal-800/40 border border-emerald-500/30 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-emerald-500 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/30 group-hover:scale-105 transition">
                  <Play className="w-5 h-5 fill-slate-950 ml-0.5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-emerald-200">
                  ভিডিও দেখুন
                </span>
                <span className="text-[10px] text-emerald-400/70 -mt-1">
                  {primaryVideo ? 'তৈরি আছে' : 'ডিফল্ট'}
                </span>
              </button>

              {/* 2. Quranic Ayahs of Solace */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  playChimePeace();
                  onOpenQuranModal();
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-400 flex items-center justify-center text-slate-950 shadow-lg shadow-amber-500/20 group-hover:scale-105 transition">
                  <BookOpen className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-amber-200">
                  কোরআনের আয়াত
                </span>
                <span className="text-[10px] text-amber-400/70 -mt-1">মন শান্ত করার</span>
              </button>

              {/* 3. System Picture-in-Picture Float */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onRequestPiP();
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20 group-hover:scale-105 transition">
                  <Maximize2 className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-sky-200">
                  অন্য অ্যাপে ভাসান
                </span>
                <span className="text-[10px] text-sky-400/70 -mt-1">Picture-in-Pic</span>
              </button>

              {/* 4. Upload Motivation Video */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenUpload();
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 group-hover:scale-105 transition">
                  <Upload className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-purple-200">
                  ভিডিও আপলোড
                </span>
                <span className="text-[10px] text-purple-400/70 -mt-1">গ্যালারি / ফাইল</span>
              </button>

              {/* 5. Breathing Box Exercise for Anxiety */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenBreathingModal();
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-teal-400 to-cyan-600 flex items-center justify-center text-slate-950 shadow-lg shadow-teal-500/20 group-hover:scale-105 transition">
                  <Wind className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-teal-200">
                  গভীর নিঃশ্বাস
                </span>
                <span className="text-[10px] text-teal-400/70 -mt-1">অস্থিরতা কমান</span>
              </button>

              {/* 6. Settings / Customize Orb */}
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenSettingsTab();
                }}
                className="group flex flex-col items-center justify-center gap-2 p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 transition active:scale-95 cursor-pointer text-center"
              >
                <div className="w-11 h-11 rounded-2xl bg-slate-800 border border-white/20 flex items-center justify-center text-slate-300 shadow-md group-hover:scale-105 transition">
                  <Sliders className="w-5 h-5" />
                </div>
                <span className="text-xs font-semibold font-bangla leading-tight text-slate-300">
                  আইকন সেটিং
                </span>
                <span className="text-[10px] text-slate-400 -mt-1">রং ও সাইজ</span>
              </button>
            </div>

            {/* Bottom Current Video Status Footer */}
            <div className="rounded-2xl bg-white/5 border border-white/10 p-2.5 flex items-center justify-between">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <div className="truncate">
                  <p className="text-[11px] text-slate-400 font-bangla">বর্তমান প্রাইমারি ভিডিও:</p>
                  <p className="text-xs font-semibold text-slate-200 truncate">
                    {primaryVideo?.title || 'ডিফল্ট অনুপ্রেরণামূলক ক্লিপ'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsMenuOpen(false);
                  onOpenVideoPlayer(primaryVideo || undefined);
                }}
                className="shrink-0 text-xs text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-0.5 ml-2 cursor-pointer"
              >
                <span>চালান</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
