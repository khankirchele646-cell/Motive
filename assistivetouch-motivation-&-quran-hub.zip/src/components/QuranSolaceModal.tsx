import React, { useState, useEffect } from 'react';
import { QuranAyah } from '../types';
import { CURATED_QURAN_VERSES } from '../data/curatedQuran';
import { 
  X, 
  Volume2, 
  VolumeX, 
  Heart, 
  Share2, 
  Sparkles, 
  ChevronRight, 
  ChevronLeft, 
  Check, 
  RefreshCw,
  BookOpen
} from 'lucide-react';
import { playChimePeace, playHapticTick, speakText, stopSpeaking } from '../lib/soundEffects';

interface Props {
  initialAyah?: QuranAyah | null;
  isOpen: boolean;
  favoriteIds: string[];
  onToggleFavorite: (id: string) => void;
  onClose: () => void;
}

export const QuranSolaceModal: React.FC<Props> = ({
  initialAyah,
  isOpen,
  favoriteIds,
  onToggleFavorite,
  onClose,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (initialAyah) {
      const idx = CURATED_QURAN_VERSES.findIndex((v) => v.id === initialAyah.id);
      if (idx !== -1) setCurrentIndex(idx);
    } else {
      // Pick a random comforting verse when opening fresh
      const rand = Math.floor(Math.random() * CURATED_QURAN_VERSES.length);
      setCurrentIndex(rand);
    }
  }, [initialAyah, isOpen]);

  const currentVerse = CURATED_QURAN_VERSES[currentIndex] || CURATED_QURAN_VERSES[0];
  const isFavorite = favoriteIds.includes(currentVerse.id);

  const handleNext = () => {
    playHapticTick();
    stopSpeaking();
    setIsSpeaking(false);
    setCurrentIndex((prev) => (prev + 1) % CURATED_QURAN_VERSES.length);
  };

  const handlePrev = () => {
    playHapticTick();
    stopSpeaking();
    setIsSpeaking(false);
    setCurrentIndex((prev) => (prev - 1 + CURATED_QURAN_VERSES.length) % CURATED_QURAN_VERSES.length);
  };

  const handleToggleAudio = () => {
    playHapticTick();
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
    } else {
      playChimePeace();
      // Read Bengali comforting reflection or Arabic
      speakText(`${currentVerse.bangla}। ${currentVerse.reflectionBn}`, 'bn-BD');
      setIsSpeaking(true);
    }
  };

  const handleCopy = async () => {
    playHapticTick();
    const textToCopy = `${currentVerse.arabic}\n\n"${currentVerse.bangla}"\n- সূরা ${currentVerse.surah} (${currentVerse.surahNumber}:${currentVerse.verseNumber})\n\n💡 ${currentVerse.reflectionBn}`;
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      // clipboard error fallback
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in"
      onClick={() => {
        stopSpeaking();
        onClose();
      }}
    >
      <div
        className="w-full max-w-lg rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/80 border border-emerald-500/30 p-6 shadow-2xl text-white relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle decorative Islamic arch background watermark */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none -ml-20 -mb-20" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-emerald-300">
                  সূরা {currentVerse.surah} ({currentVerse.surahNumber}:{currentVerse.verseNumber})
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bangla">
                  {currentVerse.categoryLabelBn}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-bangla mt-0.5">
                হতাশা ও কঠিন সময়ে অন্তরের সান্ত্বনা
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                playHapticTick();
                onToggleFavorite(currentVerse.id);
              }}
              className={`p-2 rounded-xl border transition cursor-pointer ${
                isFavorite
                  ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                  : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
              }`}
              title="পছন্দের তালিকায় রাখুন"
            >
              <Heart className={`w-4 h-4 ${isFavorite ? 'fill-rose-400' : ''}`} />
            </button>
            <button
              onClick={() => {
                stopSpeaking();
                onClose();
              }}
              className="p-2 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Arabic Ayah Calligraphy Card */}
        <div className="my-5 rounded-2xl bg-slate-950/60 border border-emerald-500/20 p-5 text-center relative shadow-inner">
          <p
            dir="rtl"
            className="font-quran text-2xl sm:text-3xl leading-[2.2] text-amber-100 font-semibold tracking-wide drop-shadow-md select-text"
          >
            {currentVerse.arabic}
          </p>
        </div>

        {/* Bengali Translation */}
        <div className="space-y-3 font-bangla select-text">
          <div className="rounded-2xl bg-white/5 border border-white/10 p-4">
            <h4 className="text-xs font-semibold text-emerald-400 mb-1 flex items-center gap-1.5">
              <span>অর্থ ও মর্মবাণী:</span>
            </h4>
            <p className="text-base text-slate-100 leading-relaxed font-medium">
              "{currentVerse.bangla}"
            </p>
          </div>

          {/* Reflection for Despair */}
          <div className="rounded-2xl bg-emerald-950/40 border border-emerald-500/30 p-3.5 flex items-start gap-2.5">
            <Sparkles className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-semibold text-emerald-300">হতাশায় ভেঙে পড়বেন না:</p>
              <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                {currentVerse.reflectionBn}
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls & Navigation */}
        <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between gap-2">
          {/* Audio & Copy Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleToggleAudio}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition cursor-pointer ${
                isSpeaking
                  ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-lg shadow-emerald-500/30'
                  : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
              }`}
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span className="font-bangla">{isSpeaking ? 'থামান' : 'শুনুন'}</span>
            </button>

            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-300 transition cursor-pointer font-bangla"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি হয়েছে' : 'কপি করুন'}</span>
            </button>
          </div>

          {/* Carousel Next / Prev */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handlePrev}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition cursor-pointer"
              title="পূর্ববর্তী আয়াত"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs text-slate-400 font-mono px-1">
              {currentIndex + 1} / {CURATED_QURAN_VERSES.length}
            </span>
            <button
              onClick={handleNext}
              className="p-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 hover:text-white transition cursor-pointer"
              title="পরবর্তী আয়াত"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
