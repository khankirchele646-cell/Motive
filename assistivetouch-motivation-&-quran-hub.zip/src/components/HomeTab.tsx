import React from 'react';
import { MotivationVideo, QuranAyah, AssistiveTouchSettings } from '../types';
import { 
  Play, 
  Sparkles, 
  BookOpen, 
  ShieldCheck, 
  Upload, 
  HardDrive, 
  Compass, 
  Layers, 
  Flame, 
  HeartHandshake,
  CheckCircle2,
  Info,
  Download
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { playChimePeace, playHapticTick } from '../lib/soundEffects';

interface Props {
  primaryVideo: MotivationVideo | null;
  settings: AssistiveTouchSettings;
  featuredAyah: QuranAyah;
  videoCount: number;
  storageMB: string;
  onOpenVideoPlayer: (v?: MotivationVideo) => void;
  onOpenQuranModal: (a?: QuranAyah) => void;
  onOpenUpload: () => void;
  onRequestPiP: () => void;
  onNavigateTab: (tab: 'videos' | 'quran' | 'touch_settings' | 'settings') => void;
  onOpenApkModal: () => void;
}

export const HomeTab: React.FC<Props> = ({
  primaryVideo,
  settings,
  featuredAyah,
  videoCount,
  storageMB,
  onOpenVideoPlayer,
  onOpenQuranModal,
  onOpenUpload,
  onRequestPiP,
  onNavigateTab,
  onOpenApkModal,
}) => {
  return (
    <div className="space-y-6 pb-24">
      {/* Hero Solace Trigger Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950/70 to-slate-950 border border-emerald-500/30 p-6 shadow-2xl text-white">
        {/* Decorative background glow */}
        <div className="absolute -top-16 -right-16 w-56 h-56 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold mb-3">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>আইফোন স্টাইল ভাসমান মোটিভেশন হাব</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-white leading-tight font-bangla">
            কখনো নিরাশ হবেন না, <br />
            <span className="bg-gradient-to-r from-emerald-300 via-teal-200 to-amber-200 bg-clip-text text-transparent">
              অন্ধকারের পরই নতুন সূর্য ওঠে।
            </span>
          </h2>

          <p className="mt-2 text-xs sm:text-sm text-slate-300 font-bangla leading-relaxed max-w-md">
            স্ক্রিনে থাকা আইফোনের গোল আইকনটিতে এক স্পর্শেই চালু হবে আপনার পছন্দের মোটিভেশন ভিডিও ও কোরআনের আয়াত। সম্পূর্ণ অফলাইনে, কোনো লগইন ঝামেলা ছাড়া।
          </p>

          {/* Quick Panic Action Buttons */}
          <div className="mt-5 flex flex-wrap gap-2.5">
            <button
              onClick={() => {
                playChimePeace();
                onOpenVideoPlayer(primaryVideo || undefined);
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs sm:text-sm font-bold shadow-lg shadow-emerald-500/30 active:scale-95 transition cursor-pointer"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span className="font-bangla">হতাশা দূর করতে ভিডিও চালান</span>
            </button>

            <button
              onClick={() => {
                playChimePeace();
                onOpenQuranModal(featuredAyah);
              }}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs sm:text-sm font-semibold text-slate-200 active:scale-95 transition cursor-pointer"
            >
              <BookOpen className="w-4 h-4 text-amber-300" />
              <span className="font-bangla">আজকের আয়াত পড়ুন</span>
            </button>
          </div>
        </div>

        {/* Floating Orb State Indicator */}
        <div className="mt-5 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-bangla text-slate-300">
              ভাসমান আইকন স্ক্রিনে সক্রিয় (টেনে যেকোনো পাশে রাখুন)
            </span>
          </div>
          <button
            onClick={() => onNavigateTab('touch_settings')}
            className="text-emerald-400 hover:text-emerald-300 font-medium text-xs font-bangla underline underline-offset-4"
          >
            কাস্টমাইজ
          </button>
        </div>
      </div>

      {/* PWA Install Banner */}
      <PWAInstallButton variant="banner" />

      {/* Direct Android APK Download Banner */}
      <div className="rounded-2xl bg-gradient-to-r from-slate-900 via-sky-950/60 to-slate-900 border border-sky-500/30 p-4 shadow-xl">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center shrink-0">
              <Download className="w-5 h-5 text-sky-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-bold text-white font-bangla">অ্যান্ড্রয়েড APK ডাউনলোড</h4>
                <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-sky-500/20 text-sky-300 font-mono">
                  .APK
                </span>
              </div>
              <p className="text-xs text-slate-300 font-bangla mt-0.5">
                মোবাইলে সরাসরি ইনস্টল করুন অথবা PWABuilder দিয়ে .apk প্যাকেজ নামিয়ে নিন।
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playHapticTick();
              onOpenApkModal();
            }}
            className="shrink-0 flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 active:scale-95 text-slate-950 text-xs font-bold shadow-lg shadow-sky-500/25 transition cursor-pointer font-bangla"
          >
            <Download className="w-3.5 h-3.5" />
            <span>APK নিন</span>
          </button>
        </div>
      </div>

      {/* Today's Solace Quran Verse Card */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-amber-400">
            <Sparkles className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider font-bangla">
              আজকের সান্ত্বনা (সূরা {featuredAyah.surah})
            </span>
          </div>
          <span className="text-[11px] text-slate-400 font-bangla">
            {featuredAyah.categoryLabelBn}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-amber-500/20 text-center my-3">
          <p dir="rtl" className="font-quran text-lg sm:text-xl leading-loose text-amber-100">
            {featuredAyah.arabic}
          </p>
        </div>

        <p className="text-sm font-bangla text-slate-200 font-medium leading-relaxed">
          "{featuredAyah.bangla}"
        </p>

        <p className="mt-2 text-xs font-bangla text-emerald-400/90">
          💡 {featuredAyah.reflectionBn}
        </p>

        <div className="mt-4 flex items-center justify-between pt-3 border-t border-slate-800 text-xs">
          <button
            onClick={() => {
              playChimePeace();
              onOpenQuranModal(featuredAyah);
            }}
            className="text-amber-400 hover:text-amber-300 font-bangla font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>সম্পূর্ণ অর্থ ও অডিও শুনুন</span>
            <span>→</span>
          </button>
          <button
            onClick={() => onNavigateTab('quran')}
            className="text-slate-400 hover:text-white font-bangla"
          >
            সব আয়াত দেখুন
          </button>
        </div>
      </div>

      {/* Primary Video Status & Quick PiP */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2 text-emerald-400">
            <Play className="w-4 h-4 fill-emerald-400" />
            <span className="text-xs font-bold uppercase tracking-wider font-bangla">
              প্রাইমারি মোটিভেশন ভিডিও
            </span>
          </div>
          <button
            onClick={() => onNavigateTab('videos')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-bangla underline underline-offset-4"
          >
            পরিবর্তন করুন
          </button>
        </div>

        <div className="flex items-center gap-4 p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
          <div className="w-16 h-14 rounded-xl bg-slate-800 overflow-hidden relative shrink-0 flex items-center justify-center">
            {primaryVideo?.thumbnail ? (
              <img
                src={primaryVideo.thumbnail}
                alt="thumb"
                className="w-full h-full object-cover"
              />
            ) : (
              <Play className="w-6 h-6 text-emerald-400 fill-emerald-400" />
            )}
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
              <Play className="w-4 h-4 fill-white" />
            </div>
          </div>

          <div className="truncate flex-1">
            <h4 className="text-sm font-semibold text-slate-100 truncate">
              {primaryVideo?.title || 'অনুপ্রেরণামূলক নতুন ভোর'}
            </h4>
            <p className="text-xs text-slate-400 font-bangla mt-0.5 truncate">
              {primaryVideo?.customNote || 'আইকন ট্যাপ করলে এই ভিডিওটি স্ক্রিনে প্লে হবে'}
            </p>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                playChimePeace();
                onOpenVideoPlayer(primaryVideo || undefined);
              }}
              className="p-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition cursor-pointer"
              title="ভিডিও প্লে করুন"
            >
              <Play className="w-4 h-4 fill-slate-950" />
            </button>
            <button
              onClick={onRequestPiP}
              className="p-2.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-sky-300 transition cursor-pointer"
              title="অন্য সব অ্যাপের উপরে ভাসিয়ে রাখুন (Picture-in-Picture)"
            >
              <Layers className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tip for floating on other apps */}
        <div className="mt-3 flex items-start gap-2 p-2.5 rounded-xl bg-sky-950/30 border border-sky-500/20 text-[11px] text-sky-200 font-bangla">
          <Info className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
          <span>
            <strong>টিপস:</strong> উপরের <Layers className="w-3.5 h-3.5 inline mx-0.5 text-sky-300" /> আইকনে চাপলে ভিডিওটি Picture-in-Picture মোডে চলে যাবে, যার ফলে আপনি ফেসবুক বা অন্য যেকোনো অ্যাপ চালালেও স্ক্রিনের একপাশে ভিডিওটি ভাসমান থাকবে!
          </span>
        </div>
      </div>

      {/* Offline & Privacy Assurance Badge */}
      <div className="rounded-2xl bg-slate-900/50 border border-slate-800/80 p-4 flex items-center justify-between text-xs text-slate-400 font-bangla">
        <div className="flex items-center gap-2.5">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <p className="text-slate-200 font-semibold">১০০% অফলাইন ও ব্যক্তিগত মেমোরি</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              কোনো সাইন-ইন বা ক্লাউড সংযোগের প্রয়োজন নেই। ডাটা ডিভাইসেই সুরক্ষিত থাকে।
            </p>
          </div>
        </div>
        <div className="text-right shrink-0">
          <span className="font-mono text-emerald-400 font-bold">{videoCount}</span> ভিডিও
          <p className="text-[10px] text-slate-500">{storageMB} MB ব্যবহৃত</p>
        </div>
      </div>
    </div>
  );
};
