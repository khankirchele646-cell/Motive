import React from 'react';
import { 
  ShieldCheck, 
  HardDrive, 
  Download, 
  Trash2, 
  Smartphone, 
  CheckCircle2, 
  Layers, 
  Lock, 
  WifiOff, 
  Info,
  HeartHandshake,
  Sparkles
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { playHapticTick } from '../lib/soundEffects';

interface Props {
  storageMB: string;
  videoCount: number;
  onClearAllData: () => void;
  onRequestPiP: () => void;
  onOpenApkModal: () => void;
}

export const SettingsTab: React.FC<Props> = ({
  storageMB,
  videoCount,
  onClearAllData,
  onRequestPiP,
  onOpenApkModal,
}) => {
  return (
    <div className="space-y-6 pb-24 text-white">
      {/* Privacy Guarantee Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/60 to-slate-900 border border-emerald-500/30 p-5 shadow-xl">
        <div className="flex items-center gap-2.5 text-emerald-400 mb-2">
          <ShieldCheck className="w-5 h-5" />
          <h2 className="text-base font-bold font-bangla">১০০% অফলাইন ও লগইন-মুক্ত নিশ্চয়তা</h2>
        </div>
        <p className="text-xs text-slate-300 font-bangla leading-relaxed">
          আপনার অনুরোধ অনুযায়ী, এই অ্যাপটিতে কোনো প্রকার ChatGPT বা ক্লাউড সাইন-ইনের ঝামেলা রাখা হয়নি। আপনি ব্রাউজার থেকে বের হয়ে পরে আবার ফিরে আসলেও আপনার সংরক্ষিত ভিডিও ও সেটিংস হুবহু সুরক্ষিত থাকবে।
        </p>
      </div>

      {/* Android APK Download & WebAPK Card */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950/50 to-slate-900 border border-sky-500/30 p-5 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-sky-400">
            <Download className="w-4 h-4" />
            <h3 className="text-sm font-bold font-bangla">অ্যান্ড্রয়েড APK ফাইল ডাউনলোড ও ইনস্টল</h3>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-mono">
            .APK Package
          </span>
        </div>
        <p className="text-xs text-slate-300 font-bangla mb-4 leading-relaxed">
          আপনার অ্যান্ড্রয়েড ফোনে সরাসরি .APK ফাইল ডাউনলোড করতে চান? নিচে চাপ দিয়ে সরাসরি প্যাকেজ তৈরি করে ফোনে ইন্সটল করে নিন।
        </p>
        <button
          onClick={() => {
            playHapticTick();
            onOpenApkModal();
          }}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-sky-600 to-blue-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-sky-700/30 hover:brightness-110 active:scale-[0.99] transition cursor-pointer font-bangla"
        >
          <Download className="w-4 h-4" />
          <span>অ্যান্ড্রয়েড .APK ডাউনলোড সেন্টার খুলুন</span>
        </button>
      </div>

      {/* PWA Install Card */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
        <div className="flex items-center gap-2 text-emerald-400 mb-2">
          <Smartphone className="w-4 h-4" />
          <h3 className="text-sm font-bold font-bangla">স্মার্টফোনে ইন্সটল (Home Screen App)</h3>
        </div>
        <p className="text-xs text-slate-300 font-bangla mb-4 leading-relaxed">
          অ্যাপটি একবার আপনার ফোনে ইন্সটল করে নিলে এটি হোমস্ক্রিনের আসল অ্যাপের মতো কাজ করবে। ইন্টারনেট সংযোগ ছাড়াই সবসময় চলবে।
        </p>
        <PWAInstallButton variant="button" />
      </div>

      {/* How to Float Video Over Other Apps (Picture-in-Picture) */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
        <div className="flex items-center gap-2 text-sky-400 mb-2">
          <Layers className="w-4 h-4" />
          <h3 className="text-sm font-bold font-bangla">অন্য সব অ্যাপের উপর ভাসমান রাখার নিয়ম</h3>
        </div>
        <p className="text-xs text-slate-300 font-bangla leading-relaxed">
          আপনি চান যেন ফেসবুক, মেসেঞ্জার বা অন্য কোনো অ্যাপ চালালেও স্ক্রিনের একপাশে আপনার মোটিভেশন ভিডিও ভাসমান থাকে। আধুনিক প্রযুক্তির <strong>Picture-in-Picture (PiP)</strong> ফিচারের মাধ্যমে এটি একদম সম্ভব!
        </p>

        <div className="my-3 p-3.5 rounded-2xl bg-slate-950/80 border border-sky-500/30 text-xs font-bangla text-sky-200 space-y-1.5">
          <p>
            ১. ভিডিও প্লেয়ারে থাকা <strong>‘Picture-in-Picture’ (<Layers className="w-3.5 h-3.5 inline mx-0.5 text-sky-400" />)</strong> বাটনে চাপ দিন।
          </p>
          <p>
            ২. ভিডিওটি ছোট একটি ভাসমান উইন্ডোতে রূপ নেবে যা আপনি স্ক্রিনের যেকোনো কোণায় সরিয়ে রাখতে পারেন।
          </p>
          <p>
            ৩. এবার যেকোনো অ্যাপে যান, ভিডিওটি স্ক্রিনেই বাজতে থাকবে!
          </p>
        </div>

        <button
          onClick={() => {
            playHapticTick();
            onRequestPiP();
          }}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 border border-sky-500/40 text-xs font-bold text-sky-300 transition cursor-pointer"
        >
          <Layers className="w-4 h-4" />
          <span className="font-bangla">এখনই ভাসমান মোড পরীক্ষা করুন</span>
        </button>
      </div>

      {/* Local Storage & IndexedDB Status */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl">
        <div className="flex items-center gap-2 text-slate-200 mb-3">
          <HardDrive className="w-4 h-4 text-emerald-400" />
          <h3 className="text-sm font-bold font-bangla">ডিভাইস স্টোরেজ স্থিতি</h3>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 font-bangla">ব্যবহৃত মেমোরি</span>
            <p className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
              {storageMB} <span className="text-xs">MB</span>
            </p>
          </div>
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800">
            <span className="text-xs text-slate-400 font-bangla">সংরক্ষিত ভিডিও</span>
            <p className="text-lg font-bold text-white font-mono mt-0.5">
              {videoCount} <span className="text-xs font-bangla">টি</span>
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            playHapticTick();
            if (
              confirm(
                'আপনি কি ডিভাইসে সংরক্ষিত সকল কাস্টম ভিডিও ও সেটিংস মুছে একদম নতুন অবস্থায় ফিরিয়ে নিতে চান?'
              )
            ) {
              onClearAllData();
            }
          }}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-semibold transition cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span className="font-bangla">ক্লিন ও রিসেট করুন (Reset Storage)</span>
        </button>
      </div>

      {/* Developer & Spiritual Note */}
      <div className="rounded-2xl bg-slate-950/60 border border-slate-800/80 p-4 text-center font-bangla text-xs text-slate-400">
        <HeartHandshake className="w-5 h-5 mx-auto text-emerald-400 mb-1" />
        <p className="font-semibold text-slate-300">
          "আল্লাহর রহমত থেকে কখনও নিরাশ হবেন না।"
        </p>
        <p className="text-[11px] text-slate-500 mt-1">
          Developed with care for your spiritual solace and mental strength.
        </p>
      </div>
    </div>
  );
};
