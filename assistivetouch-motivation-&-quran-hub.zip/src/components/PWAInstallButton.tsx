import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, Share2, PlusSquare, X, CheckCircle2 } from 'lucide-react';

interface Props {
  variant?: 'banner' | 'button' | 'compact';
}

export const PWAInstallButton: React.FC<Props> = ({ variant = 'button' }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [justInstalled, setJustInstalled] = useState(false);

  // If already installed in standalone mode
  if (isInstalled) {
    if (variant === 'banner') return null;
    return (
      <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-3 py-1.5 rounded-full">
        <CheckCircle2 className="w-3.5 h-3.5" />
        <span>অ্যাপ হিসেবে ইন্সটল করা আছে</span>
      </div>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) {
        setJustInstalled(true);
      }
    } else if (isIOS) {
      setShowIOSGuide(true);
    } else {
      // General instructions for chrome/android
      setShowIOSGuide(true);
    }
  };

  return (
    <>
      {variant === 'banner' ? (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-900/60 via-slate-900/80 to-teal-950/70 border border-emerald-500/25 p-4 shadow-xl backdrop-blur-md">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-white">ফোনে ইন্সটল করুন (PWA App)</h4>
                <p className="text-xs text-slate-300 mt-0.5 font-bangla">
                  ব্রাউজার ছাড়াই আসল অ্যাপের মতো অফলাইনে ভাসমান আইকন ও ভিডিও চালান।
                </p>
              </div>
            </div>
            <button
              onClick={handleInstallClick}
              className="shrink-0 flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 text-xs font-semibold shadow-lg shadow-emerald-500/25 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>ইন্সটল</span>
            </button>
          </div>
        </div>
      ) : variant === 'compact' ? (
        <button
          onClick={handleInstallClick}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-medium transition cursor-pointer"
          title="Install app to your device"
        >
          <Download className="w-3.5 h-3.5" />
          <span>ইন্সটল অ্যাপ</span>
        </button>
      ) : (
        <button
          onClick={handleInstallClick}
          className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-emerald-700/30 hover:brightness-110 active:scale-[0.99] transition cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>ফোনে অ্যাপ হিসেবে সেভ করুন (Install PWA)</span>
        </button>
      )}

      {/* iOS & Manual Installation Instructions Modal */}
      {showIOSGuide && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl text-left">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-base">
                <Smartphone className="w-5 h-5" />
                <span>ফোনের স্ক্রিনে যুক্ত করার নিয়ম</span>
              </div>
              <button
                onClick={() => setShowIOSGuide(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-sm text-slate-300 font-bangla">
              {isIOS ? (
                <>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ১
                    </span>
                    <p>
                      iPhone Safari ব্রাউজারের নিচে থাকা <Share2 className="w-4 h-4 inline text-blue-400 mx-1" /> <strong>Share</strong> বাটনে ট্যাপ করুন।
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ২
                    </span>
                    <p>
                      নিচে স্ক্রল করে <PlusSquare className="w-4 h-4 inline text-emerald-400 mx-1" /> <strong>Add to Home Screen</strong> সিলেক্ট করুন।
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ৩
                    </span>
                    <p>
                      উপরে <strong>Add</strong> চাপলেই আইফোনের মতো হোমস্ক্রিন আইকন তৈরি হয়ে যাবে!
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ১
                    </span>
                    <p>
                      ব্রাউজারের উপরের বা নিচের <strong>⋮ (তিন ডট)</strong> মেনুতে চাপ দিন।
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ২
                    </span>
                    <p>
                      <strong>Install app</strong> অথবা <strong>Add to Home screen</strong> অপশন চাপুন।
                    </p>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold text-xs">
                      ৩
                    </span>
                    <p>
                      এখন আপনি অন্য যেকোনো অ্যাপের মতো এটি ব্যবহার করতে পারবেন সম্পূর্ণ অফলাইনে!
                    </p>
                  </div>
                </>
              )}
            </div>

            <button
              onClick={() => setShowIOSGuide(false)}
              className="mt-6 w-full rounded-xl bg-slate-800 hover:bg-slate-700 py-2.5 text-sm font-medium text-white transition"
            >
              বুঝেছি (Close)
            </button>
          </div>
        </div>
      )}
    </>
  );
};
