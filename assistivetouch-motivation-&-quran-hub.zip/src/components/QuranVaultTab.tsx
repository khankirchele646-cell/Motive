import React, { useState } from 'react';
import { QuranAyah } from '../types';
import { CURATED_QURAN_VERSES } from '../data/curatedQuran';
import { 
  BookOpen, 
  Search, 
  Heart, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Share2, 
  Check, 
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { playChimePeace, playHapticTick, speakText, stopSpeaking } from '../lib/soundEffects';

interface Props {
  favoriteIds: string[];
  onToggleFavorite: (id: string) => void;
  onOpenAyahModal: (ayah: QuranAyah) => void;
}

export const QuranVaultTab: React.FC<Props> = ({
  favoriteIds,
  onToggleFavorite,
  onOpenAyahModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'সব আয়াত' },
    { id: 'favorites', label: `প্রিয় (${favoriteIds.length})` },
    { id: 'despair', label: 'হতাশা দূরীকরণ' },
    { id: 'hardship', label: 'কষ্টের পর স্বস্তি' },
    { id: 'strength', label: 'মনের শক্তি' },
    { id: 'peace', label: 'মানসিক শান্তি' },
    { id: 'provision', label: 'রিজিক ও সংকট' },
  ];

  const filteredVerses = CURATED_QURAN_VERSES.filter((v) => {
    // Category match
    if (activeCategory === 'favorites' && !favoriteIds.includes(v.id)) return false;
    if (activeCategory !== 'all' && activeCategory !== 'favorites' && v.category !== activeCategory) {
      return false;
    }

    // Search query match
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      v.surah.toLowerCase().includes(q) ||
      v.bangla.toLowerCase().includes(q) ||
      v.reflectionBn.toLowerCase().includes(q) ||
      v.english.toLowerCase().includes(q)
    );
  });

  const handleAudioToggle = (ayah: QuranAyah) => {
    playHapticTick();
    if (playingId === ayah.id) {
      stopSpeaking();
      setPlayingId(null);
    } else {
      stopSpeaking();
      playChimePeace();
      speakText(`${ayah.bangla}। ${ayah.reflectionBn}`, 'bn-BD');
      setPlayingId(ayah.id);
    }
  };

  const handleCopy = async (ayah: QuranAyah) => {
    playHapticTick();
    const text = `${ayah.arabic}\n\n"${ayah.bangla}"\n- সূরা ${ayah.surah} (${ayah.surahNumber}:${ayah.verseNumber})\n\n💡 ${ayah.reflectionBn}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(ayah.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (e) {
      // fallback
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/50 to-slate-900 border border-emerald-500/30 p-5 shadow-xl text-white">
        <div className="flex items-center gap-2.5 text-emerald-400 mb-1">
          <BookOpen className="w-5 h-5" />
          <h2 className="text-base font-bold font-bangla">কোরআনের প্রশান্তি ও প্রেরণা</h2>
        </div>
        <p className="text-xs text-slate-300 font-bangla leading-relaxed">
          যখন আপনি হতাশায় ভুগবেন বা অন্তরে অস্থিরতা লাগবে, এই পবিত্র আয়াতগুলো অন্তরে প্রশান্তি ও আশা ফিরিয়ে দেবে।
        </p>

        {/* Search Input */}
        <div className="relative mt-4">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="আয়াত খুঁজুন (যেমন: নিরাশ, কষ্ট, ধৈর্য, রিজিক, প্রশান্তি)..."
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-950/80 border border-slate-700/80 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition"
          />
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 pb-1 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                playHapticTick();
                setActiveCategory(cat.id);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer font-bangla ${
                activeCategory === cat.id
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10 border border-white/10'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Verses List */}
      <div className="space-y-4">
        {filteredVerses.length === 0 ? (
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-8 text-center text-slate-400 font-bangla">
            <BookOpen className="w-8 h-8 mx-auto text-slate-600 mb-2" />
            <p className="text-sm">কোনো আয়াত পাওয়া যায়নি। অন্য শব্দ দিয়ে খুঁজে দেখুন।</p>
          </div>
        ) : (
          filteredVerses.map((ayah) => {
            const isFav = favoriteIds.includes(ayah.id);
            const isPlaying = playingId === ayah.id;
            const isCopied = copiedId === ayah.id;

            return (
              <div
                key={ayah.id}
                className="rounded-3xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 p-5 shadow-xl text-white transition-all duration-200"
              >
                {/* Verse Header */}
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono text-xs font-bold">
                      {ayah.surahNumber}
                    </span>
                    <div>
                      <h4 className="text-sm font-bold text-slate-100">
                        সূরা {ayah.surah} ({ayah.surahNumber}:{ayah.verseNumber})
                      </h4>
                      <p className="text-[11px] text-emerald-400 font-bangla">
                        {ayah.categoryLabelBn}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        playHapticTick();
                        onToggleFavorite(ayah.id);
                      }}
                      className={`p-2 rounded-xl border transition cursor-pointer ${
                        isFav
                          ? 'bg-rose-500/20 border-rose-500/40 text-rose-400'
                          : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                      }`}
                      title="পছন্দের তালিকায় রাখুন"
                    >
                      <Heart className={`w-3.5 h-3.5 ${isFav ? 'fill-rose-400' : ''}`} />
                    </button>

                    <button
                      onClick={() => handleCopy(ayah)}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white transition cursor-pointer"
                      title="কপি করুন"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                {/* Arabic Script */}
                <div className="my-3.5 p-3.5 rounded-2xl bg-slate-950/70 border border-emerald-500/20 text-center">
                  <p dir="rtl" className="font-quran text-lg sm:text-xl leading-loose text-amber-100 select-text">
                    {ayah.arabic}
                  </p>
                </div>

                {/* Bengali Translation */}
                <p className="text-sm font-bangla text-slate-200 font-medium leading-relaxed select-text">
                  "{ayah.bangla}"
                </p>

                {/* Reflection Note */}
                <div className="mt-3 p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 flex items-start gap-2 text-xs font-bangla text-emerald-300">
                  <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>পরামর্শ:</strong> {ayah.reflectionBn}
                  </p>
                </div>

                {/* Action Footer */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <button
                    onClick={() => handleAudioToggle(ayah)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bangla transition cursor-pointer ${
                      isPlaying
                        ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-semibold'
                        : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    {isPlaying ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                    <span>{isPlaying ? 'বন্ধ করুন' : 'অডিও শুনুন'}</span>
                  </button>

                  <button
                    onClick={() => {
                      playChimePeace();
                      onOpenAyahModal(ayah);
                    }}
                    className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-bangla font-semibold cursor-pointer"
                  >
                    <span>বড় করে পড়ুন</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
