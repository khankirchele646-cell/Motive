import React from 'react';
import { AssistiveTouchSettings, OrbTheme, OrbIcon, OrbClickBehavior } from '../types';
import { 
  Sliders, 
  Sparkles, 
  Moon, 
  Heart, 
  Flame, 
  Play, 
  Check, 
  Layers, 
  Smartphone, 
  Vibrate, 
  Eye, 
  RotateCcw
} from 'lucide-react';
import { playHapticTick, playChimePeace } from '../lib/soundEffects';

interface Props {
  settings: AssistiveTouchSettings;
  onUpdateSettings: (newSettings: Partial<AssistiveTouchSettings>) => void;
  onResetSettings: () => void;
}

export const AssistiveTouchStudioTab: React.FC<Props> = ({
  settings,
  onUpdateSettings,
  onResetSettings,
}) => {
  const themes: { id: OrbTheme; label: string; bg: string; border: string; glow: string }[] = [
    { id: 'emerald', label: 'এমেরাল্ড নূর (Emerald)', bg: 'bg-emerald-500', border: 'border-emerald-400', glow: 'shadow-emerald-500/40' },
    { id: 'apple-dark', label: 'আসল আইফোন (Apple Dark)', bg: 'bg-slate-300', border: 'border-white', glow: 'shadow-white/30' },
    { id: 'gold', label: 'সোনালী আলো (Pure Gold)', bg: 'bg-amber-400', border: 'border-amber-300', glow: 'shadow-amber-500/40' },
    { id: 'sky', label: 'আকাশী প্রশান্তি (Cyan Sky)', bg: 'bg-sky-400', border: 'border-sky-300', glow: 'shadow-sky-500/40' },
    { id: 'rose', label: 'কোমল মমতা (Rose Heart)', bg: 'bg-rose-400', border: 'border-rose-300', glow: 'shadow-rose-500/40' },
    { id: 'amethyst', label: 'অ্যামেথিস্ট (Amethyst)', bg: 'bg-purple-400', border: 'border-purple-300', glow: 'shadow-purple-500/40' },
  ];

  const icons: { id: OrbIcon; label: string; icon: React.ReactNode }[] = [
    { id: 'classic-touch', label: 'আইফোন রিং', icon: <div className="w-5 h-5 rounded-full border-2 border-white flex items-center justify-center"><div className="w-2 h-2 rounded-full bg-white" /></div> },
    { id: 'crescent', label: 'চাঁদ', icon: <Moon className="w-5 h-5 text-emerald-400" /> },
    { id: 'heart', label: 'হৃদয়', icon: <Heart className="w-5 h-5 text-rose-400" /> },
    { id: 'sparkles', label: 'নূর / আশা', icon: <Sparkles className="w-5 h-5 text-amber-400" /> },
    { id: 'flame', label: 'তেজ / আগুন', icon: <Flame className="w-5 h-5 text-orange-400" /> },
    { id: 'play', label: 'ভিডিও প্লে', icon: <Play className="w-5 h-5 text-emerald-400 fill-emerald-400" /> },
  ];

  const clickBehaviors: { id: OrbClickBehavior; title: string; desc: string }[] = [
    { id: 'open_menu', title: 'রেডিয়াল মেনু খুলবে (পরামর্শিত)', desc: 'আইফোনের মতো ৬টি অপশন আসবে (ভিডিও, আয়াত, নিঃশ্বাস ইত্যাদি)' },
    { id: 'play_primary_video', title: 'সরাসরি ভিডিও প্লে হবে', desc: 'আইকনে চাপ দেওয়া মাত্রই প্রাইমারি ভিডিও পপ-আপ হয়ে চালু হবে' },
    { id: 'show_quran_verse', title: 'সরাসরি কোরআনের আয়াত দেখাবে', desc: 'আইকনে চাপ দিলে সান্ত্বনাদায়ক নতুন একটি আয়াত খুলে যাবে' },
  ];

  return (
    <div className="space-y-6 pb-24">
      {/* Studio Header Card */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/50 border border-emerald-500/30 p-5 shadow-xl text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold font-bangla">ভাসমান আইকন স্টুডিও (AssistiveTouch)</h2>
              <p className="text-xs text-slate-400 font-bangla">
                আইফোনের গোল আইকনের মতো দেখতে আপনার ব্যক্তিগত মোটিভেশন বাটনটি সাজান
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              playHapticTick();
              onResetSettings();
            }}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white transition cursor-pointer"
            title="ডিফল্ট সেটিংস রিসেট করুন"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Live Preview Box */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-6 shadow-xl text-center">
        <p className="text-xs font-semibold text-slate-400 font-bangla uppercase tracking-wider mb-4">
          লাইভ প্রিভিউ (বর্তমান আইকনের রূপ)
        </p>

        <div className="w-full h-32 rounded-2xl bg-slate-950/80 border border-dashed border-slate-700/80 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="text-[11px] text-slate-500 font-bangla mb-2">
            স্ক্রিনে এই আইকনটি সবসময় দৃশ্যমান থাকবে এবং যেকোনো পাশে ড্র্যাগ করা যাবে
          </div>

          {/* Sample Rendered Orb */}
          <div
            style={{
              width: `${settings.size}px`,
              height: `${settings.size}px`,
              opacity: settings.activeOpacity,
            }}
            className="rounded-[28%] p-1.5 flex items-center justify-center backdrop-blur-xl bg-slate-950/80 border border-white/20 shadow-2xl transition-all duration-300"
          >
            <div className="w-full h-full rounded-[26%] bg-slate-800/90 border border-white/20 flex items-center justify-center shadow-inner">
              {settings.iconStyle === 'classic-touch' ? (
                <div className="w-[58%] h-[58%] rounded-full bg-white shadow-md flex items-center justify-center ring-2 ring-white/30">
                  <div className="w-[45%] h-[45%] rounded-full bg-slate-900" />
                </div>
              ) : settings.iconStyle === 'crescent' ? (
                <Moon className="w-[60%] h-[60%] text-emerald-300 fill-emerald-300/40" />
              ) : settings.iconStyle === 'heart' ? (
                <Heart className="w-[60%] h-[60%] text-rose-400 fill-rose-400/40" />
              ) : settings.iconStyle === 'sparkles' ? (
                <Sparkles className="w-[60%] h-[60%] text-amber-300" />
              ) : settings.iconStyle === 'flame' ? (
                <Flame className="w-[60%] h-[60%] text-orange-400 fill-orange-400/40" />
              ) : (
                <Play className="w-[55%] h-[55%] text-emerald-400 fill-emerald-400 ml-0.5" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Theme Color Picker */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white">
        <h3 className="text-sm font-bold font-bangla mb-3">আইকনের রঙ ও গ্লো থিম (Color Glow)</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
          {themes.map((t) => {
            const isSelected = settings.theme === t.id;
            return (
              <button
                key={t.id}
                onClick={() => {
                  playHapticTick();
                  onUpdateSettings({ theme: t.id });
                }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition cursor-pointer ${
                  isSelected
                    ? 'bg-slate-800 border-emerald-400/80 shadow-lg'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className={`w-5 h-5 rounded-full ${t.bg} shadow-md shrink-0`} />
                <span className="text-xs font-semibold text-slate-200 truncate font-bangla">
                  {t.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Center Icon Symbol Picker */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white">
        <h3 className="text-sm font-bold font-bangla mb-3">আইকনের ভেতরের প্রতীক (Glyph Symbol)</h3>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5">
          {icons.map((ic) => {
            const isSelected = settings.iconStyle === ic.id;
            return (
              <button
                key={ic.id}
                onClick={() => {
                  playHapticTick();
                  onUpdateSettings({ iconStyle: ic.id });
                }}
                className={`flex flex-col items-center justify-center gap-2 p-3 rounded-2xl border transition cursor-pointer ${
                  isSelected
                    ? 'bg-emerald-500/15 border-emerald-400 shadow-md'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="w-8 h-8 rounded-xl bg-slate-800 flex items-center justify-center">
                  {ic.icon}
                </div>
                <span className="text-[11px] font-bangla text-slate-300 font-medium">
                  {ic.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Click Action Behavior */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white">
        <h3 className="text-sm font-bold font-bangla mb-3">আইকন ট্যাপ করার সাথে সাথে কী ঘটবে?</h3>
        <div className="space-y-2.5">
          {clickBehaviors.map((b) => {
            const isSelected = settings.clickBehavior === b.id;
            return (
              <div
                key={b.id}
                onClick={() => {
                  playHapticTick();
                  onUpdateSettings({ clickBehavior: b.id });
                }}
                className={`p-3.5 rounded-2xl border cursor-pointer transition flex items-start gap-3 ${
                  isSelected
                    ? 'bg-emerald-950/40 border-emerald-400/80 shadow-md'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full border-2 mt-0.5 flex items-center justify-center shrink-0 ${
                    isSelected ? 'border-emerald-400 bg-emerald-500' : 'border-slate-600'
                  }`}
                >
                  {isSelected && <Check className="w-3 h-3 text-slate-950 stroke-[3]" />}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-100 font-bangla">{b.title}</h4>
                  <p className="text-[11px] text-slate-400 font-bangla mt-0.5">{b.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sliders for Size & Opacity */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white space-y-5">
        {/* Size Slider */}
        <div>
          <div className="flex items-center justify-between text-xs font-bangla mb-2">
            <span className="text-slate-300 font-semibold">আইকনের আকার (Size):</span>
            <span className="text-emerald-400 font-mono font-bold">{settings.size} px</span>
          </div>
          <input
            type="range"
            min="44"
            max="78"
            step="2"
            value={settings.size}
            onChange={(e) => onUpdateSettings({ size: Number(e.target.value) })}
            className="w-full accent-emerald-500 cursor-pointer"
          />
        </div>

        {/* Inactive Idle Opacity Slider */}
        <div>
          <div className="flex items-center justify-between text-xs font-bangla mb-2">
            <span className="text-slate-300 font-semibold">
              নিষ্ক্রিয় থাকলে হালকা হওয়ার মাত্রা (Idle Opacity):
            </span>
            <span className="text-emerald-400 font-mono font-bold">
              {Math.round(settings.idleOpacity * 100)}%
            </span>
          </div>
          <input
            type="range"
            min="0.2"
            max="1.0"
            step="0.05"
            value={settings.idleOpacity}
            onChange={(e) => onUpdateSettings({ idleOpacity: Number(e.target.value) })}
            className="w-full accent-emerald-500 cursor-pointer"
          />
          <p className="text-[11px] text-slate-400 font-bangla mt-1">
            আইফোনের মতো কিছুক্ষণ না ছুঁলে আইকনটি স্বয়ংক্রিয়ভাবে ঝাপসা হয়ে যাবে যাতে স্ক্রিন দেখতে সমস্যা না হয়।
          </p>
        </div>
      </div>

      {/* Toggles */}
      <div className="rounded-3xl bg-slate-900/90 border border-slate-800 p-5 shadow-xl text-white space-y-4">
        {/* Snap to edge */}
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-bangla">
              স্ক্রিনের কিনারায় স্বয়ংক্রিয় চুম্বকের মতো লেগে থাকা (Edge Snap)
            </h4>
            <p className="text-[11px] text-slate-400 font-bangla mt-0.5">
              ছেড়ে দিলে আইকনটি নিজে থেকেই ডান বা বাম কিনারায় আটকে যাবে
            </p>
          </div>
          <button
            onClick={() => {
              playHapticTick();
              onUpdateSettings({ snapToEdge: !settings.snapToEdge });
            }}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.snapToEdge ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                settings.snapToEdge ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        {/* Haptic sound */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <div>
            <h4 className="text-xs font-bold text-slate-200 font-bangla">
              স্পর্শে টিক শব্দ ও কম্পন (Haptic Click)
            </h4>
            <p className="text-[11px] text-slate-400 font-bangla mt-0.5">
              আইকন ড্র্যাগ বা ট্যাপ করলে আইফোনের মতো স্পর্শ অনুভূতি
            </p>
          </div>
          <button
            onClick={() => {
              playHapticTick();
              onUpdateSettings({ hapticFeedback: !settings.hapticFeedback });
            }}
            className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
              settings.hapticFeedback ? 'bg-emerald-500' : 'bg-slate-700'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform transform absolute top-0.5 ${
                settings.hapticFeedback ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>
      </div>
    </div>
  );
};
