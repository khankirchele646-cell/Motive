import React, { useState, useRef } from 'react';
import { MotivationVideo } from '../types';
import { 
  Upload, 
  Play, 
  Trash2, 
  CheckCircle, 
  Star, 
  Layers, 
  Plus, 
  Film, 
  HelpCircle, 
  Clock, 
  HardDrive,
  Info,
  ChevronDown,
  ChevronUp,
  Sparkles
} from 'lucide-react';
import { playChimePeace, playHapticTick } from '../lib/soundEffects';

interface Props {
  videos: MotivationVideo[];
  onUploadVideo: (file: File, title: string, customNote: string) => Promise<void>;
  onSetPrimary: (id: string) => void;
  onDeleteVideo: (id: string) => void;
  onPlayVideo: (v: MotivationVideo) => void;
  onRequestPiP: () => void;
}

export const VideoVaultTab: React.FC<Props> = ({
  videos,
  onUploadVideo,
  onSetPrimary,
  onDeleteVideo,
  onPlayVideo,
  onRequestPiP,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [titleInput, setTitleInput] = useState('');
  const [noteInput, setNoteInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showGuide, setShowGuide] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      if (!titleInput) {
        setTitleInput(file.name.replace(/\.[^/.]+$/, ''));
      }
    }
  };

  const handleSaveUpload = async () => {
    if (!selectedFile) return;
    playHapticTick();
    setIsUploading(true);
    try {
      await onUploadVideo(
        selectedFile,
        titleInput.trim() || selectedFile.name,
        noteInput.trim() || 'হতাশায় মনকে শক্তি জোগাতে'
      );
      setSelectedFile(null);
      setTitleInput('');
      setNoteInput('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      playChimePeace();
    } catch (err) {
      console.error('Upload failed:', err);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-6 pb-24">
      {/* Upload Box Card */}
      <div className="rounded-3xl bg-gradient-to-b from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 p-5 shadow-2xl text-white">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold">নতুন মোটিভেশন ভিডিও যুক্ত করুন</h3>
              <p className="text-[11px] text-slate-400 font-bangla">
                আপনার স্টোরেজ থেকে ভিডিও ফাইল নির্বাচন করুন (IndexedDB তে সেভ থাকবে)
              </p>
            </div>
          </div>
        </div>

        {/* Hidden Native File Input */}
        <input
          ref={fileInputRef}
          type="file"
          accept="video/*"
          className="hidden"
          onChange={handleFileChange}
        />

        {/* Upload Trigger Area */}
        {!selectedFile ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="my-4 border-2 border-dashed border-emerald-500/30 hover:border-emerald-400/60 rounded-2xl p-6 text-center cursor-pointer transition bg-emerald-950/20 hover:bg-emerald-950/40 group"
          >
            <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition mb-3">
              <Film className="w-6 h-6" />
            </div>
            <p className="text-sm font-semibold text-slate-100 font-bangla">
              মোবাইল বা পিসি থেকে ভিডিও আপলোড করতে এখানে চাপুন
            </p>
            <p className="text-xs text-slate-400 font-bangla mt-1">
              MP4, WebM, MOV, MKV ইত্যাদি যেকোনো সাইজের ভিডিও সম্পূর্ণ অফলাইনে সেভ হবে
            </p>
          </div>
        ) : (
          <div className="my-4 p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/40 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <div className="flex items-center gap-2 truncate">
                <Film className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-semibold truncate">{selectedFile.name}</span>
              </div>
              <span className="text-slate-400 shrink-0 ml-2 font-mono">
                {(selectedFile.size / (1024 * 1024)).toFixed(1)} MB
              </span>
            </div>

            {/* Title Input */}
            <div>
              <label className="text-xs text-slate-300 font-bangla mb-1 block">
                ভিডিওর নাম (Title):
              </label>
              <input
                type="text"
                value={titleInput}
                onChange={(e) => setTitleInput(e.target.value)}
                placeholder="যেমন: হতাশা জয়ের অনুপ্রেরণা"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Note Input */}
            <div>
              <label className="text-xs text-slate-300 font-bangla mb-1 block">
                স্মরণিকা নোট (ভিডিও দেখার সময় স্ক্রিনে ভেসে উঠবে):
              </label>
              <input
                type="text"
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
                placeholder="যেমন: মনে রেখো, আল্লাহ কখনো ধৈর্যশীলদের নিরাশ করেন না"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={handleSaveUpload}
                disabled={isUploading}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs sm:text-sm font-bold transition shadow-lg shadow-emerald-500/25 disabled:opacity-50 cursor-pointer"
              >
                {isUploading ? (
                  <span>সংরক্ষণ করা হচ্ছে...</span>
                ) : (
                  <>
                    <CheckCircle className="w-4 h-4" />
                    <span className="font-bangla">মেমোরিতে সেভ করুন (Save)</span>
                  </>
                )}
              </button>
              <button
                onClick={() => {
                  setSelectedFile(null);
                  if (fileInputRef.current) fileInputRef.current.value = '';
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-300 font-bangla cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          </div>
        )}

        {/* Video Download Guide Accordion */}
        <div className="pt-2">
          <button
            onClick={() => setShowGuide(!showGuide)}
            className="w-full flex items-center justify-between text-xs text-emerald-400/90 hover:text-emerald-300 py-1 font-bangla cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>ইন্টারনেট থেকে ভিডিও ডাউনলোড করে এখানে রাখার উপায়</span>
            </span>
            {showGuide ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {showGuide && (
            <div className="mt-2.5 p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 font-bangla space-y-2 animate-fade-in">
              <p className="font-semibold text-emerald-300">
                যেভাবে আপনার পছন্দের মোটিভেশন ভিডিও সংগ্রহ করবেন:
              </p>
              <ol className="list-decimal list-inside space-y-1.5 text-slate-300 leading-relaxed">
                <li>
                  YouTube Shorts, Facebook Reels বা TikTok-এ আপনার পছন্দের কোনো অনুপ্রেরণামূলক বা কোরআন তিলাওয়াত ভিডিও দেখুন।
                </li>
                <li>
                  ভিডিওর লিংক কপি করে যেকোনো ফ্রি ডাউনলোডার সাইট দিয়ে আপনার ফোনের মেমোরিতে (Gallery/Files) ডাউনলোড করে রাখুন।
                </li>
                <li>
                  এবার এই অ্যাপে এসে <strong>‘ভিডিও আপলোড’</strong> বাটনে চাপ দিয়ে সেই ফাইলটি সিলেক্ট করে দিন।
                </li>
                <li>
                  এটি সরাসরি আপনার ব্রাউজারের সুরক্ষিত মেমোরিতে স্থায়ীভাবে থেকে যাবে। ইন্টারনেট বন্ধ থাকলেও সবসময় চলবে!
                </li>
              </ol>
            </div>
          )}
        </div>
      </div>

      {/* Videos List Section */}
      <div>
        <div className="flex items-center justify-between mb-4 px-1">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white font-bangla">
              সংরক্ষিত মোটিভেশন ভিডিওসমূহ ({videos.length}টি)
            </h3>
          </div>
          <p className="text-xs text-slate-400 font-bangla">
            আইকনে চাপ দিলে সরাসরি প্রাইমারি ভিডিওটি প্লে হয়
          </p>
        </div>

        <div className="space-y-3">
          {videos.map((vid) => {
            const isBlob = !!vid.blob;
            const fileSizeMB = vid.blob ? (vid.blob.size / (1024 * 1024)).toFixed(1) : null;

            return (
              <div
                key={vid.id}
                className={`group rounded-2xl p-4 border transition-all duration-200 ${
                  vid.isPrimary
                    ? 'bg-gradient-to-r from-emerald-950/60 via-slate-900 to-slate-900 border-emerald-500/50 shadow-lg shadow-emerald-950/30'
                    : 'bg-slate-900/80 hover:bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {/* Thumbnail / Play trigger */}
                    <div
                      onClick={() => {
                        playChimePeace();
                        onPlayVideo(vid);
                      }}
                      className="w-16 h-16 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden relative shrink-0 cursor-pointer flex items-center justify-center group-hover:border-emerald-500/50 transition"
                    >
                      {vid.thumbnail ? (
                        <img
                          src={vid.thumbnail}
                          alt={vid.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Film className="w-6 h-6 text-emerald-400" />
                      )}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition">
                        <Play className="w-5 h-5 fill-white text-white drop-shadow" />
                      </div>
                    </div>

                    {/* Metadata */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-sm font-bold text-slate-100 truncate">
                          {vid.title}
                        </h4>
                        {vid.isPrimary && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                            <Star className="w-3 h-3 fill-emerald-300" />
                            <span>প্রাইমারি আইকন ভিডিও</span>
                          </span>
                        )}
                      </div>

                      {vid.customNote && (
                        <p className="text-xs text-slate-300 font-bangla mt-1 line-clamp-1">
                          💡 {vid.customNote}
                        </p>
                      )}

                      <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400 font-bangla">
                        <span>{isBlob ? 'ডিভাইস ফাইল' : 'বিল্ট-ইন'}</span>
                        {fileSizeMB && <span>{fileSizeMB} MB</span>}
                        {vid.duration && <span>{vid.duration} সে.</span>}
                      </div>
                    </div>
                  </div>

                  {/* Actions Column */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => {
                        playChimePeace();
                        onPlayVideo(vid);
                      }}
                      className="p-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 transition cursor-pointer"
                      title="প্লে করুন"
                    >
                      <Play className="w-4 h-4 fill-emerald-400" />
                    </button>

                    {!vid.isPrimary && (
                      <button
                        onClick={() => {
                          playHapticTick();
                          onSetPrimary(vid.id);
                        }}
                        className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-amber-400 transition cursor-pointer"
                        title="প্রাইমারি ভিডিও হিসেবে সেট করুন (আইকন চাপলে এটি চলবে)"
                      >
                        <Star className="w-4 h-4" />
                      </button>
                    )}

                    {isBlob && (
                      <button
                        onClick={() => {
                          playHapticTick();
                          if (confirm(`আপনি কি "${vid.title}" মুছে ফেলতে চান?`)) {
                            onDeleteVideo(vid.id);
                          }
                        }}
                        className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition cursor-pointer"
                        title="মুছে ফেলুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
