import React, { useState, useRef, useEffect } from 'react';
import { MotivationVideo } from '../types';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize2, 
  Minimize2, 
  X, 
  Repeat, 
  SkipForward, 
  Move, 
  Sparkles,
  Layers,
  Heart
} from 'lucide-react';
import { playHapticTick } from '../lib/soundEffects';

interface Props {
  video: MotivationVideo | null;
  allVideos: MotivationVideo[];
  isOpen: boolean;
  onClose: () => void;
  onSelectVideo: (v: MotivationVideo) => void;
}

export const FloatingMiniPlayer: React.FC<Props> = ({
  video,
  allVideos,
  isOpen,
  onClose,
  onSelectVideo,
}) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [isLooping, setIsLooping] = useState(true);
  const [isExpanded, setIsExpanded] = useState(false);
  const [position, setPosition] = useState({ x: 20, y: 80 });
  const [isDragging, setIsDragging] = useState(false);
  const [hasPipSupport, setHasPipSupport] = useState(false);
  const [videoError, setVideoError] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const dragRef = useRef({ startX: 0, startY: 0, posX: 0, posY: 0 });

  useEffect(() => {
    if (typeof document !== 'undefined') {
      setHasPipSupport('pictureInPictureEnabled' in document);
    }
  }, []);

  // Reset error when video changes
  useEffect(() => {
    setVideoError(false);
    setIsPlaying(true);
  }, [video?.id]);

  // Pointer drag for floating window
  const handlePointerDown = (e: React.PointerEvent) => {
    // Only drag from top title bar
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setIsDragging(true);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      posX: position.x,
      posY: position.y,
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPosition({
      x: Math.max(10, Math.min(window.innerWidth - 320, dragRef.current.posX + dx)),
      y: Math.max(10, Math.min(window.innerHeight - 240, dragRef.current.posY + dy)),
    });
  };

  const handlePointerUp = () => {
    setIsDragging(false);
  };

  const togglePlay = () => {
    playHapticTick();
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = () => {
    playHapticTick();
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const togglePiP = async () => {
    playHapticTick();
    if (!videoRef.current) return;
    try {
      if (document.pictureInPictureElement) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (err) {
      console.warn('PiP not available or permission denied:', err);
    }
  };

  const handleNextVideo = () => {
    playHapticTick();
    if (!allVideos.length) return;
    const currentIndex = allVideos.findIndex((v) => v.id === video?.id);
    const nextIndex = (currentIndex + 1) % allVideos.length;
    onSelectVideo(allVideos[nextIndex]);
  };

  if (!isOpen || !video) return null;

  const videoSource = video.blobUrl || video.videoUrl;

  return (
    <div
      style={{
        transform: `translate3d(${position.x}px, ${position.y}px, 0)`,
        width: isExpanded ? 'min(92vw, 480px)' : 'min(88vw, 340px)',
      }}
      className="fixed top-0 left-0 z-[92] rounded-2xl overflow-hidden bg-slate-950/95 border border-slate-700/80 shadow-[0_12px_40px_rgba(0,0,0,0.8)] backdrop-blur-2xl transition-[width] duration-300 animate-scale-up"
    >
      {/* Draggable Title Header */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="flex items-center justify-between px-3 py-2 bg-slate-900/90 border-b border-slate-800 cursor-move select-none touch-none text-xs"
      >
        <div className="flex items-center gap-2 truncate pr-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
          <span className="font-semibold text-slate-200 truncate">
            {video.title}
          </span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          {hasPipSupport && (
            <button
              onClick={togglePiP}
              title="Float on other apps (Picture-in-Picture)"
              className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={() => setIsExpanded((prev) => !prev)}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          <button
            onClick={() => {
              playHapticTick();
              onClose();
            }}
            className="p-1 rounded-lg hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Video Viewport */}
      <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden group">
        {videoError || !videoSource ? (
          <div className="flex flex-col items-center justify-center p-6 text-center text-slate-400 gap-2">
            <Sparkles className="w-8 h-8 text-amber-400 animate-bounce" />
            <p className="text-xs font-bangla text-slate-300">
              ভিডিও ফাইলটি ডিভাইসে প্রস্তুত হচ্ছে। আপনি আপনার নিজের মোটিভেশন ভিডিও আপলোড করতে পারেন।
            </p>
          </div>
        ) : (
          <video
            ref={videoRef}
            src={videoSource}
            autoPlay
            playsInline
            loop={isLooping}
            muted={isMuted}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onError={() => setVideoError(true)}
            className="w-full h-full object-contain"
          />
        )}

        {/* Play/Pause Overlay Hit Area */}
        <div
          onClick={togglePlay}
          className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
        >
          <div className="w-12 h-12 rounded-full bg-slate-900/80 border border-white/20 flex items-center justify-center text-white shadow-xl backdrop-blur-md">
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-white ml-0.5" />}
          </div>
        </div>

        {/* Motivational note badge overlay */}
        {video.customNote && (
          <div className="absolute bottom-2 left-2 right-2 p-2 rounded-lg bg-black/75 border border-white/10 backdrop-blur-md text-[11px] text-slate-200 font-bangla line-clamp-2 pointer-events-none">
            💡 {video.customNote}
          </div>
        )}
      </div>

      {/* Mini Player Control Bar */}
      <div className="px-3 py-2 bg-slate-900/90 border-t border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={togglePlay}
            className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition cursor-pointer"
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-emerald-400" />}
          </button>
          <button
            onClick={toggleMute}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-300 hover:text-white transition cursor-pointer"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => {
              playHapticTick();
              setIsLooping(!isLooping);
            }}
            title={isLooping ? 'লুপ চালু (পুনরাবৃত্তি)' : 'লুপ বন্ধ'}
            className={`p-1.5 rounded-lg transition cursor-pointer ${
              isLooping ? 'bg-emerald-500/20 text-emerald-400' : 'text-slate-400 hover:bg-slate-800'
            }`}
          >
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center gap-1.5">
          {allVideos.length > 1 && (
            <button
              onClick={handleNextVideo}
              title="পরবর্তী ভিডিও"
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bangla transition cursor-pointer"
            >
              <span>পরবর্তী</span>
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          )}

          {hasPipSupport && (
            <button
              onClick={togglePiP}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-500/15 border border-sky-500/30 text-sky-300 hover:bg-sky-500/25 text-xs transition cursor-pointer"
              title="Picture in Picture Mode"
            >
              <Layers className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PiP</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
