import React, { useState } from 'react';
import { 
  X, 
  Smartphone, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  Layers, 
  CheckCircle2, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { playHapticTick, playChimePeace } from '../lib/soundEffects';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const ApkDownloadModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const [copied, setCopied] = useState(false);

  // Development & shared URL for this applet
  const appUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-mfczqmqgoyoyimbmtps2ed-775002460131.asia-northeast1.run.app';
  const cleanAppUrl = 'https://ais-pre-mfczqmqgoyoyimbmtps2ed-775002460131.asia-northeast1.run.app';

  // PWABuilder direct link to generate signed .apk
  const pwaBuilderUrl = `https://www.pwabuilder.com/reportcard?site=${encodeURIComponent(cleanAppUrl)}`;

  const handleCopyLink = async () => {
    playHapticTick();
    try {
      await navigator.clipboard.writeText(cleanAppUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch (e) {
      // fallback
    }
  };

  const handleDirectInstall = async () => {
    playHapticTick();
    if (isInstallable) {
      await install();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[110] flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-fade-in text-white"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl bg-slate-900 border border-emerald-500/40 p-6 shadow-2xl relative overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle decorative glow */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10 relative z-10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-1.5 font-bangla">
                <span>অ্যান্ড্রয়েড APK ও সরাসরি ইন্সটল</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono">
                  APK / WebAPK
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-bangla">
                আপনার ফোনে আসল অ্যাপ হিসেবে নামিয়ে নেওয়ার সহজ উপায়
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playHapticTick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="my-4 space-y-4 font-bangla text-xs text-slate-300">
          {/* Method 1: Instant Direct 1-Click Install on Android (Recommended) */}
          <div className="rounded-2xl bg-emerald-950/40 border border-emerald-500/40 p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <span className="inline-block text-[11px] font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-md mb-1.5">
                  পদ্ধতি ১ (সবচেয়ে সহজ ও দ্রুত)
                </span>
                <h4 className="text-sm font-bold text-white">
                  ফোনে সরাসরি WebAPK অ্যাপ হিসেবে ইন্সটল করুন
                </h4>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  গুগল ক্রোমের মাধ্যমে অ্যান্ড্রয়েড সিস্টেম স্বয়ংক্রিয়ভাবে একটি নিজস্ব <strong>.APK</strong> তৈরি করে হোমস্ক্রিনে অ্যাপ হিসেবে যুক্ত করে দেয়।
                </p>
              </div>
            </div>

            <div className="mt-3 flex items-center gap-2">
              {isInstallable ? (
                <button
                  onClick={handleDirectInstall}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/25 transition cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>এখনই ফোনে ইন্সটল করুন (Install WebAPK)</span>
                </button>
              ) : isInstalled ? (
                <div className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-300 font-medium text-xs">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>ইতিমধ্যে আপনার ফোনে ইন্সটল করা রয়েছে</span>
                </div>
              ) : (
                <div className="w-full p-2.5 rounded-xl bg-slate-950/70 border border-emerald-500/30 text-[11px] text-slate-300 space-y-1">
                  <p className="font-semibold text-emerald-300">অ্যান্ড্রয়েড ফোনের ক্রোম (Chrome) থেকে:</p>
                  <p>১. উপরে ডানপাশে <strong>⋮ (৩ ডট)</strong> মেনুতে চাপ দিন।</p>
                  <p>২. <strong>"Install app"</strong> বা <strong>"Add to Home screen"</strong> চাপুন।</p>
                  <p>৩. সাথে সাথে ফোনের অ্যাপ লিস্টে আইকন চলে আসবে!</p>
                </div>
              )}
            </div>
          </div>

          {/* Method 2: Download raw .APK file via PWABuilder */}
          <div className="rounded-2xl bg-slate-950/70 border border-slate-700/80 p-4">
            <span className="inline-block text-[11px] font-bold text-sky-300 bg-sky-500/20 px-2 py-0.5 rounded-md mb-1.5">
              পদ্ধতি ২ (অফলাইন .APK ফাইল ডাউনলোড)
            </span>
            <h4 className="text-sm font-bold text-white">
              PWABuilder দিয়ে সরাসরি .APK ফাইল ডাউনলোড করুন
            </h4>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              মাইক্রোসফটের অফিশিয়াল <strong>PWABuilder</strong> এই অ্যাপের লিংক দিয়ে ২ মিনিটে সম্পূর্ণ সাইন করা অ্যান্ড্রয়েড ইনস্টলার <strong>.apk</strong> ফাইল তৈরি করে দেয় যা ফাইল ম্যানেজারে ডাউনলোড করে ইন্সটল করা যায়।
            </p>

            <div className="mt-3 space-y-2">
              <a
                href={pwaBuilderUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={playHapticTick}
                className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow-lg shadow-sky-600/25 transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>PWABuilder-এ APK জেনারেট করুন (Download .APK)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <p className="text-[10px] text-slate-400 text-center">
                PWABuilder পেজে গিয়ে শুধু <strong>"Package for Android"</strong> বাটন চাপলেই .apk ডাউনলোড শুরু হবে।
              </p>
            </div>
          </div>

          {/* Copy Direct Link Section */}
          <div className="rounded-2xl bg-slate-950/70 border border-slate-800 p-3.5 flex items-center justify-between gap-2">
            <div className="truncate flex-1">
              <span className="text-[11px] text-slate-400 block mb-0.5">অ্যাপের শেয়ারেবল লিংক:</span>
              <p className="text-xs font-mono text-emerald-400 truncate">
                {cleanAppUrl}
              </p>
            </div>
            <button
              onClick={handleCopyLink}
              className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-xs text-slate-200 transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'কপি হয়েছে' : 'লিংক কপি'}</span>
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-white/10 flex items-center justify-end">
          <button
            onClick={() => {
              playHapticTick();
              onClose();
            }}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition cursor-pointer font-bangla"
          >
            বুঝেছি (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
