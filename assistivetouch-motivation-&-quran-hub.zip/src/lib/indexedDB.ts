import { AssistiveTouchSettings, MotivationVideo, QuranAyah } from '../types';

const DB_NAME = 'MotivOrb_Database';
const DB_VERSION = 1;

interface DBSchema {
  videos: MotivationVideo;
  settings: { key: string; value: any };
  favorites: { ayahId: string; timestamp: number };
}

let dbInstance: IDBDatabase | null = null;

export async function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;

      if (!db.objectStoreNames.contains('videos')) {
        const videoStore = db.createObjectStore('videos', { keyPath: 'id' });
        videoStore.createIndex('dateAdded', 'dateAdded', { unique: false });
        videoStore.createIndex('isPrimary', 'isPrimary', { unique: false });
      }

      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' });
      }

      if (!db.objectStoreNames.contains('favorites')) {
        db.createObjectStore('favorites', { keyPath: 'ayahId' });
      }
    };

    request.onsuccess = (event) => {
      dbInstance = (event.target as IDBOpenDBRequest).result;
      resolve(dbInstance);
    };

    request.onerror = (event) => {
      reject((event.target as IDBOpenDBRequest).error);
    };
  });
}

// ---------------- VIDEO STORAGE ----------------

export async function saveVideo(video: MotivationVideo): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('videos', 'readwrite');
    const store = tx.objectStore('videos');

    // If marked primary, unset other primaries
    if (video.isPrimary) {
      const getAllReq = store.getAll();
      getAllReq.onsuccess = () => {
        const all = getAllReq.result as MotivationVideo[];
        for (const item of all) {
          if (item.id !== video.id && item.isPrimary) {
            item.isPrimary = false;
            store.put(item);
          }
        }
      };
    }

    const putReq = store.put(video);
    putReq.onsuccess = () => resolve();
    putReq.onerror = () => reject(putReq.error);
  });
}

export async function getAllVideos(): Promise<MotivationVideo[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('videos', 'readonly');
    const store = tx.objectStore('videos');
    const request = store.getAll();

    request.onsuccess = () => {
      const videos = (request.result as MotivationVideo[]) || [];
      // Generate object URLs for any stored Blobs
      const mapped = videos.map((v) => {
        if (v.blob) {
          const url = URL.createObjectURL(v.blob);
          return { ...v, blobUrl: url };
        }
        return v;
      });
      // Sort: primary first, then newest
      mapped.sort((a, b) => {
        if (a.isPrimary) return -1;
        if (b.isPrimary) return 1;
        return b.dateAdded - a.dateAdded;
      });
      resolve(mapped);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function deleteVideo(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('videos', 'readwrite');
    const store = tx.objectStore('videos');
    const request = store.delete(id);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

export async function setPrimaryVideo(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('videos', 'readwrite');
    const store = tx.objectStore('videos');
    const request = store.getAll();

    request.onsuccess = () => {
      const list = request.result as MotivationVideo[];
      for (const item of list) {
        item.isPrimary = item.id === id;
        store.put(item);
      }
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

// ---------------- SETTINGS STORAGE ----------------

export const DEFAULT_ASSISTIVE_SETTINGS: AssistiveTouchSettings = {
  enabled: true,
  size: 58,
  idleOpacity: 0.45,
  activeOpacity: 0.95,
  theme: 'emerald',
  iconStyle: 'classic-touch',
  clickBehavior: 'open_menu',
  snapToEdge: true,
  hapticFeedback: true,
  position: { x: 88, y: 68 }, // percentage from top-left
};

export async function getAssistiveSettings(): Promise<AssistiveTouchSettings> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction('settings', 'readonly');
      const store = tx.objectStore('settings');
      const req = store.get('assistive_touch');

      req.onsuccess = () => {
        if (req.result && req.result.value) {
          resolve({ ...DEFAULT_ASSISTIVE_SETTINGS, ...req.result.value });
        } else {
          resolve(DEFAULT_ASSISTIVE_SETTINGS);
        }
      };
      req.onerror = () => resolve(DEFAULT_ASSISTIVE_SETTINGS);
    });
  } catch (err) {
    return DEFAULT_ASSISTIVE_SETTINGS;
  }
}

export async function saveAssistiveSettings(settings: AssistiveTouchSettings): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('settings', 'readwrite');
      const store = tx.objectStore('settings');
      const req = store.put({ key: 'assistive_touch', value: settings });

      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.error('Failed to save settings:', err);
  }
}

// ---------------- FAVORITE AYAH STORAGE ----------------

export async function getFavoriteAyahIds(): Promise<string[]> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction('favorites', 'readonly');
      const store = tx.objectStore('favorites');
      const req = store.getAll();

      req.onsuccess = () => {
        const favs = req.result as { ayahId: string }[];
        resolve(favs.map((f) => f.ayahId));
      };
      req.onerror = () => resolve([]);
    });
  } catch (err) {
    return [];
  }
}

export async function toggleFavoriteAyah(ayahId: string): Promise<boolean> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction('favorites', 'readwrite');
    const store = tx.objectStore('favorites');
    const req = store.get(ayahId);

    req.onsuccess = () => {
      if (req.result) {
        store.delete(ayahId);
        resolve(false); // un-favorited
      } else {
        store.put({ ayahId, timestamp: Date.now() });
        resolve(true); // favorited
      }
    };
    req.onerror = () => reject(req.error);
  });
}

// ---------------- STORAGE USAGE STATS ----------------

export async function calculateStorageUsage(): Promise<{ usedBytes: number; usedMB: string; count: number }> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction('videos', 'readonly');
      const store = tx.objectStore('videos');
      const req = store.getAll();

      req.onsuccess = () => {
        const videos = (req.result as MotivationVideo[]) || [];
        let total = 0;
        for (const v of videos) {
          if (v.blob) {
            total += v.blob.size;
          } else if (v.fileSize) {
            total += v.fileSize;
          }
        }
        resolve({
          usedBytes: total,
          usedMB: (total / (1024 * 1024)).toFixed(1),
          count: videos.length,
        });
      };
      req.onerror = () => resolve({ usedBytes: 0, usedMB: '0.0', count: 0 });
    });
  } catch (err) {
    return { usedBytes: 0, usedMB: '0.0', count: 0 };
  }
}
