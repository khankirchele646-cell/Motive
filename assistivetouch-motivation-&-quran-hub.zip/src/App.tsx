/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  MotivationVideo, 
  QuranAyah, 
  AssistiveTouchSettings, 
  TabType 
} from './types';
import { 
  getAssistiveSettings, 
  saveAssistiveSettings, 
  DEFAULT_ASSISTIVE_SETTINGS,
  getAllVideos,
  saveVideo,
  deleteVideo,
  setPrimaryVideo,
  getFavoriteAyahIds,
  toggleFavoriteAyah,
  calculateStorageUsage
} from './lib/indexedDB';
import { BUILTIN_MOTIVATION_VIDEOS } from './data/defaultVideos';
import { CURATED_QURAN_VERSES } from './data/curatedQuran';
import { AssistiveTouchOrb } from './components/AssistiveTouchOrb';
import { FloatingMiniPlayer } from './components/FloatingMiniPlayer';
import { QuranSolaceModal } from './components/QuranSolaceModal';
import { BreathingExerciseModal } from './components/BreathingExerciseModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { HomeTab } from './components/HomeTab';
import { VideoVaultTab } from './components/VideoVaultTab';
import { QuranVaultTab } from './components/QuranVaultTab';
import { AssistiveTouchStudioTab } from './components/AssistiveTouchStudioTab';
import { SettingsTab } from './components/SettingsTab';
import { PWAInstallButton } from './components/PWAInstallButton';
import { playHapticTick, playChimePeace } from './lib/soundEffects';
import { 
  Home, 
  Film, 
  BookOpen, 
  Sliders, 
  Settings, 
  Sparkles,
  Layers,
  Heart,
  Wind,
  Plus,
  Download,
  Smartphone
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [settings, setSettings] = useState<AssistiveTouchSettings>(DEFAULT_ASSISTIVE_SETTINGS);
  const [videos, setVideos] = useState<MotivationVideo[]>([]);
  const [favoriteAyahIds, setFavoriteAyahIds] = useState<string[]>([]);
  const [storageStats, setStorageStats] = useState<{ usedMB: string; count: number }>({ usedMB: '0.0', count: 0 });

  // Floating Player & Modals State
  const [activePlayerVideo, setActivePlayerVideo] = useState<MotivationVideo | null>(null);
  const [isPlayerOpen, setIsPlayerOpen] = useState(false);
  const [selectedAyahForModal, setSelectedAyahForModal] = useState<QuranAyah | null>(null);
  const [isQuranModalOpen, setIsQuranModalOpen] = useState(false);
  const [isBreathingModalOpen, setIsBreathingModalOpen] = useState(false);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);

  // Hidden video element for triggering Picture-in-Picture directly from UI
  const pipVideoRef = useRef<HTMLVideoElement | null>(null);

  // Load persistent data from IndexedDB on startup
  const loadData = async () => {
    try {
      const storedSettings = await getAssistiveSettings();
      setSettings(storedSettings);

      const dbVideos = await getAllVideos();
      // Combine user uploaded videos with built-in ones
      const combined = [...dbVideos];
      for (const builtin of BUILTIN_MOTIVATION_VIDEOS) {
        if (!combined.some((v) => v.id === builtin.id)) {
          combined.push(builtin);
        }
      }
      setVideos(combined);

      const favs = await getFavoriteAyahIds();
      setFavoriteAyahIds(favs);

      const stats = await calculateStorageUsage();
      setStorageStats({ usedMB: stats.usedMB, count: dbVideos.length });
    } catch (err) {
      console.error('Error loading initial data:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const primaryVideo = videos.find((v) => v.isPrimary) || videos[0] || null;
  const featuredAyah = CURATED_QURAN_VERSES[0];

  // Video Upload Handler
  const handleUploadVideo = async (file: File, title: string, customNote: string) => {
    const newVideo: MotivationVideo = {
      id: `user-video-${Date.now()}`,
      title,
      customNote,
      blob: file,
      category: 'despair',
      fileSize: file.size,
      dateAdded: Date.now(),
      isPrimary: videos.length === 0 || !videos.some((v) => v.isPrimary),
    };

    await saveVideo(newVideo);
    await loadData();
  };

  // Video Deletion Handler
  const handleDeleteVideo = async (id: string) => {
    await deleteVideo(id);
    if (activePlayerVideo?.id === id) {
      setIsPlayerOpen(false);
      setActivePlayerVideo(null);
    }
    await loadData();
  };

  // Set Primary Video Handler
  const handleSetPrimary = async (id: string) => {
    await setPrimaryVideo(id);
    await loadData();
  };

  // Toggle Favorite Ayah
  const handleToggleFavorite = async (ayahId: string) => {
    const isNowFav = await toggleFavoriteAyah(ayahId);
    if (isNowFav) {
      setFavoriteAyahIds((prev) => [...prev, ayahId]);
    } else {
      setFavoriteAyahIds((prev) => prev.filter((id) => id !== ayahId));
    }
  };

  // AssistiveTouch Settings Updates
  const handleUpdateSettings = async (updates: Partial<AssistiveTouchSettings>) => {
    const updated = { ...settings, ...updates };
    setSettings(updated);
    await saveAssistiveSettings(updated);
  };

  const handleResetSettings = async () => {
    setSettings(DEFAULT_ASSISTIVE_SETTINGS);
    await saveAssistiveSettings(DEFAULT_ASSISTIVE_SETTINGS);
  };

  // Clear Storage
  const handleClearAllData = async () => {
    indexedDB.deleteDatabase('MotivOrb_Database');
    window.location.reload();
  };

  // Trigger Native Picture-in-Picture
  const handleRequestPiP = async () => {
    playHapticTick();
    const vidToPlay = activePlayerVideo || primaryVideo || videos[0];
    if (!vidToPlay) return;

    if (!pipVideoRef.current) return;
    const src = vidToPlay.blobUrl || vidToPlay.videoUrl;
    if (!src) return;

    pipVideoRef.current.src = src;
    try {
      await pipVideoRef.current.play();
      if ('requestPictureInPicture' in pipVideoRef.current) {
        await pipVideoRef.current.requestPictureInPicture();
      } else {
        // Fallback to floating player in app
        setActivePlayerVideo(vidToPlay);
        setIsPlayerOpen(true);
      }
    } catch (e) {
      // If PiP is blocked, launch in-app floating player
      setActivePlayerVideo(vidToPlay);
      setIsPlayerOpen(true);
    }
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col relative selection:bg-emerald-500 selection:text-slate-950 font-sans">
      {/* Offline Status Badge */}
      <OfflineIndicator />

      {/* Hidden offscreen video for triggering PiP */}
      <video
        ref={pipVideoRef}
        className="hidden"
        playsInline
        muted={false}
        loop
      />

      {/* Flagship iPhone AssistiveTouch Floating Orb */}
      <AssistiveTouchOrb
        settings={settings}
        primaryVideo={primaryVideo}
        onOpenVideoPlayer={(v) => {
          setActivePlayerVideo(v || primaryVideo || videos[0] || null);
          setIsPlayerOpen(true);
        }}
        onOpenQuranModal={(a) => {
          setSelectedAyahForModal(a || null);
          setIsQuranModalOpen(true);
        }}
        onOpenUpload={() => setActiveTab('videos')}
        onOpenBreathingModal={() => setIsBreathingModalOpen(true)}
        onOpenSettingsTab={() => setActiveTab('touch_settings')}
        onRequestPiP={handleRequestPiP}
      />

      {/* Floating Mini Player (In-App Overlay Window) */}
      <FloatingMiniPlayer
        video={activePlayerVideo}
        allVideos={videos}
        isOpen={isPlayerOpen}
        onClose={() => setIsPlayerOpen(false)}
        onSelectVideo={(v) => setActivePlayerVideo(v)}
      />

      {/* Quran Ayah Solace Modal */}
      <QuranSolaceModal
        initialAyah={selectedAyahForModal}
        isOpen={isQuranModalOpen}
        favoriteIds={favoriteAyahIds}
        onToggleFavorite={handleToggleFavorite}
        onClose={() => {
          setIsQuranModalOpen(false);
          setSelectedAyahForModal(null);
        }}
      />

      {/* Calm Box Breathing Modal */}
      <BreathingExerciseModal
        isOpen={isBreathingModalOpen}
        onClose={() => setIsBreathingModalOpen(false)}
      />

      {/* Android APK Download & Installation Modal */}
      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Application Top Bar */}
      <header className="sticky top-0 z-40 bg-[#090d16]/85 backdrop-blur-xl border-b border-white/10 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {/* Mini Orb Avatar */}
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 p-0.5 shadow-lg shadow-emerald-500/20">
            <div className="w-full h-full rounded-[14px] bg-slate-950 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
          <div>
            <h1 className="text-sm font-extrabold tracking-tight text-white flex items-center gap-1.5">
              <span>MotivOrb</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                PRO
              </span>
            </h1>
            <p className="text-[10px] text-slate-400 font-bangla -mt-0.5">
              ভাসমান মোটিভেশন ও সান্ত্বনা হাব
            </p>
          </div>
        </div>

        {/* Quick Header Actions */}
        <div className="flex items-center gap-1.5">
          {/* APK Button */}
          <button
            onClick={() => {
              playHapticTick();
              setIsApkModalOpen(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-sky-500/15 hover:bg-sky-500/25 border border-sky-500/30 text-sky-300 text-xs font-bangla transition cursor-pointer"
            title="Android APK ডাউনলোড"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="font-semibold">APK</span>
          </button>

          <button
            onClick={() => {
              playChimePeace();
              setIsBreathingModalOpen(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 border border-teal-500/30 text-teal-300 text-xs font-bangla transition cursor-pointer"
            title="গভীর নিঃশ্বাস"
          >
            <Wind className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">মন শান্ত করুন</span>
          </button>

          <PWAInstallButton variant="compact" />
        </div>
      </header>

      {/* Main View Area */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-4 pt-5">
        {activeTab === 'home' && (
          <HomeTab
            primaryVideo={primaryVideo}
            settings={settings}
            featuredAyah={featuredAyah}
            videoCount={videos.length}
            storageMB={storageStats.usedMB}
            onOpenVideoPlayer={(v) => {
              setActivePlayerVideo(v || primaryVideo || videos[0] || null);
              setIsPlayerOpen(true);
            }}
            onOpenQuranModal={(a) => {
              setSelectedAyahForModal(a || null);
              setIsQuranModalOpen(true);
            }}
            onOpenUpload={() => setActiveTab('videos')}
            onRequestPiP={handleRequestPiP}
            onNavigateTab={(t) => {
              playHapticTick();
              setActiveTab(t);
            }}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}

        {activeTab === 'videos' && (
          <VideoVaultTab
            videos={videos}
            onUploadVideo={handleUploadVideo}
            onSetPrimary={handleSetPrimary}
            onDeleteVideo={handleDeleteVideo}
            onPlayVideo={(v) => {
              setActivePlayerVideo(v);
              setIsPlayerOpen(true);
            }}
            onRequestPiP={handleRequestPiP}
          />
        )}

        {activeTab === 'quran' && (
          <QuranVaultTab
            favoriteIds={favoriteAyahIds}
            onToggleFavorite={handleToggleFavorite}
            onOpenAyahModal={(a) => {
              setSelectedAyahForModal(a);
              setIsQuranModalOpen(true);
            }}
          />
        )}

        {activeTab === 'touch_settings' && (
          <AssistiveTouchStudioTab
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onResetSettings={handleResetSettings}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsTab
            storageMB={storageStats.usedMB}
            videoCount={storageStats.count}
            onClearAllData={handleClearAllData}
            onRequestPiP={handleRequestPiP}
            onOpenApkModal={() => setIsApkModalOpen(true)}
          />
        )}
      </main>

      {/* Responsive Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-2xl border-t border-white/10 px-2 py-1.5">
        <div className="max-w-md mx-auto grid grid-cols-5 gap-1">
          {/* 1. Home */}
          <button
            onClick={() => {
              playHapticTick();
              setActiveTab('home');
            }}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition cursor-pointer ${
              activeTab === 'home'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bangla">হোম</span>
          </button>

          {/* 2. Videos Vault */}
          <button
            onClick={() => {
              playHapticTick();
              setActiveTab('videos');
            }}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition cursor-pointer ${
              activeTab === 'videos'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Film className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bangla">ভিডিও</span>
          </button>

          {/* 3. Quran Ayahs */}
          <button
            onClick={() => {
              playHapticTick();
              setActiveTab('quran');
            }}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition cursor-pointer ${
              activeTab === 'quran'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bangla">কোরআন</span>
          </button>

          {/* 4. AssistiveTouch Studio */}
          <button
            onClick={() => {
              playHapticTick();
              setActiveTab('touch_settings');
            }}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition cursor-pointer ${
              activeTab === 'touch_settings'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bangla">আইকন</span>
          </button>

          {/* 5. Settings */}
          <button
            onClick={() => {
              playHapticTick();
              setActiveTab('settings');
            }}
            className={`flex flex-col items-center justify-center py-1.5 px-1 rounded-xl transition cursor-pointer ${
              activeTab === 'settings'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-5 h-5 mb-0.5" />
            <span className="text-[10px] font-bangla">সেটিংস</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
