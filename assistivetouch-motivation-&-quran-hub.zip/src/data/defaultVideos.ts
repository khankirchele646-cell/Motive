import { MotivationVideo } from '../types';

export const BUILTIN_MOTIVATION_VIDEOS: MotivationVideo[] = [
  {
    id: 'builtin-1-sunrise',
    title: 'Surrender & New Dawn (নতুন ভোর ও ঘুরে দাঁড়ানো)',
    category: 'strength',
    customNote: 'যখন ক্লান্ত লাগবে, আকাশের এই সূর্যের দিকে তাকিয়ে গভীর নিঃশ্বাস নাও। অন্ধকার কেটে আলো আসবেই।',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-sun-setting-over-the-ocean-horizon-4089-large.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80',
    duration: 24,
    dateAdded: Date.now() - 86400000 * 3,
    isPrimary: true,
  },
  {
    id: 'builtin-2-mountain',
    title: 'Unshakable Mountain Faith (পাহাড়ের মতো অবিচল ধৈর্য)',
    category: 'hardship',
    customNote: 'ঝড় যতই আসুক, পাহাড় মাথা নত করে না। তোমার আত্মবিশ্বাসও পাহাড়ের মতো দৃঢ় হোক।',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-clouds-and-blue-sky-2408-large.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=600&q=80',
    duration: 18,
    dateAdded: Date.now() - 86400000 * 2,
    isPrimary: false,
  },
  {
    id: 'builtin-3-rain',
    title: 'Peaceful Rain & Heart Healing (হৃদয়ের প্রশান্তি ও নীরবতা)',
    category: 'peace',
    customNote: 'বৃষ্টির মতো সকল দুঃখ ধুয়ে যাক। আল্লাহ অবশ্যই তোমার চোখের জলের মর্যাদা দেবেন।',
    videoUrl: 'https://assets.mixkit.co/videos/preview/mixkit-raindrops-falling-on-a-puddle-surface-42999-large.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1515694346937-94d85e41e6f0?auto=format&fit=crop&w=600&q=80',
    duration: 15,
    dateAdded: Date.now() - 86400000,
    isPrimary: false,
  }
];
